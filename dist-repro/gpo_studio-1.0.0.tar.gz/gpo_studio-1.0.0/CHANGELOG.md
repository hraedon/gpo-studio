# Changelog

All notable changes to GPO Studio are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Current version: `1.0.0`.

## [Unreleased]

> Post-1.0 development has added considerably more to `src/` than it has added
> to the operator-facing product. Entries below distinguish **surfaced**
> capabilities (reachable from the API or browser application) from **domain
> layers** (implemented and unit-tested, reachable from neither). No post-1.0
> capability is Windows-verified except where an explicit Plan 033 workpackage
> is cited.
>
> As of 2026-07-29 the unsurfaced domain layers are further classified as
> **unproven drafts, not assets awaiting wiring** — a claim about correctness,
> not only reach. Every layer an external oracle has examined has needed
> correction. See [`docs/domain-layer-status.md`](docs/domain-layer-status.md).

### Added

- Plan 023: scope-of-management, delegation, WMI-filter, and loopback support
  — **surfaced**. `som.py`, `delegation.py`, `wmi_filter.py`, and
  `ad_discovery.py` back new API endpoints for GPO links, loopback validation
  and description, AD discovery script generation/ingest
  (`/api/discovery/*`), and effective-rights evaluation. Discovery generates
  PowerShell and parses its JSON output; it performs no network I/O of its
  own, preserving the offline-first charter.
- Plan 024: full GPP adapter coverage — **surfaced**. `gpp_adapters.py`
  extends the 1.0 Groups/Registry slice across the in-box preference families
  through `gpp.py`, `canonical.py`, and `import_export.py`.
- Plans 025–032: domain layers — **not surfaced**. Security settings
  (`security_template.py`, `object_security.py`, `network_security.py`,
  `policy_families.py`), script and managed-artifact policy
  (`script_policy.py`, `artifact_store.py`), software installation and folder
  redirection (`software_install.py`, `folder_redirection.py`), GPMC lifecycle
  and interop (`lifecycle.py`, `gpmc_interop.py`), RSOP prediction
  (`rsop.py`), controlled publication (`publication.py`, `publisher.py`),
  certification (`certification.py`), and hosted control plane
  (`hosting.py`) are implemented and unit-tested, but are reachable from no
  API endpoint, UI module, or export path. They are not operator capabilities
  and are excluded from the 1.0 contract; see
  `docs/capability-matrix.md`. The publication modules are pure and emit no
  writes — the web process still never writes to AD or SYSVOL — and
  `hosting.py` does not make a hosted mode available.
- Plan 033 WP-0: Windows external-oracle evidence contract, owning-boundary
  matrix, frozen environment spec, conservative XML normalizer v1, fixture
  recipe schema, and the two-phase harness — `run-evidence.ps1` captures
  genuine raw evidence on the domain-joined host and
  `finalize_oracle_run.py` is the single authority for source provenance,
  normalization, and comparison binding. Certified pass on a clean tree with a
  full integrity pack: harness scripts, recipe, and orchestrator are hashed
  input artifacts bound to the recorded commit, every artifact rehashes
  intact, and cleanup is confirmed by an independent LDAPS re-query.
- Plan 033 WP-1A: native-origin GPMC corpus, authoring guide, and genuine
  GPMC-authored canary fixtures.
- Plan 033 remediation scenario corpus — **validation infrastructure, not a
  capability**. Thirteen provenance-graded scenarios across four families
  (gpp-services for WI-022, security-template areas for Plan 025/WP-3,
  rsop-topology for Plan 029/WP-6, ilt-os for WI-023) under
  `tests/fixtures/scenarios/`, a machine-readable test-platform registry
  (`platforms.json`) extending `docs/plan-033/environment-spec.md`, and the
  `remediation_corpus.py` loader that enforces referential integrity,
  readiness honesty (no `ready` claim on an unqualified platform), and
  sha256-pinned native-capture anchors. Executable WI-022 characterization
  probes pin today's parse/writer divergence and flip when the fix lands.
  The corpus records expected Windows behavior for the Plans 025–032
  remediation program; nothing in it is oracle-executed yet and no
  capability claim changes.
- WI-022 corrects the GPP Services typed model and wire shape against the
  genuine GPMC capture: native recovery names and omission semantics,
  `thirdFailure`, exact delay preservation, and captured extension metadata.
  It also covers the complete MS-GPPREF startup, service-action, and failure-
  action vocabularies plus the protocol-defined restart/program fields, GPMC
  report comparison, and a new WP-1B Services candidate. Its first Windows
  Server 2025 writer run passed, but the later manual capture invalidated the
  delay semantics; WI-024 corrected and recertified the candidate in clean-
  source run `wp1b-writer-20260730164352-5286`. Services is not endpoint-
  applied or authorable through the browser/API.
- WI-024 uses a dedicated GPMC Services recovery capture to correct the
  remaining wire assumptions: GPMC emits `RUNCMD`/`REBOOT`, millisecond
  restart-service and restart-computer delays, boolean `append=1`, and omits
  `serviceAction` for No change. It also confirms `program`, `args`,
  `restartMessage`, `accountName`, and `interact`. The corrected isolated and
  mixed Services candidates pass the full WP-1B Windows writer lane.
- WI-023 surfaces the modern `FilterOs` family-token limitation as a preflight
  warning and in Studio bundle manifests: `WINTHRESHOLDSRV` cannot distinguish
  Server 2016/2019/2022/2025, and `WINTHRESHOLD` cannot distinguish Windows 10
  from Windows 11. Imported OS criteria are shown read-only in the browser and
  survive edits instead of being silently dropped; build-specific targeting
  directs operators to WMI or registry predicates.

- Plan 033 WP-2: deterministic native GPMC backup emission with distinct
  backup/GPO identities, v2 `Backup.xml`, native `DomainSysvol/GPO` paths,
  verified Registry and GPP extension profiles, and a Windows Server 2025
  `Import-GPO`/re-backup/cleanup oracle lane. Native GPP output is now a strict
  allowlist: Drive Maps, Local Users and Groups, Scheduled Tasks, and Services
  are emitted; GPP Registry and uncaptured families must use the Studio bundle
  until their native extension metadata is independently verified. Services
  extension metadata is capture-backed and its Studio-origin candidate passes
  `Import-GPO`, GPMC report comparison, and `Backup-GPO` semantic comparison.
- Plan 021 WP-1: authoritative GPMC capability inventory
  (`docs/plan-021/capability-inventory.md`) — a versioned, pre-gate matrix of
  GPMC lifecycle/scope/report surfaces, principal-bearing fields, every in-box
  CSE and editor by GUID/side/storage/OS/deprecation/management-API, the GPP
  item/action/option space, and the complete ILT predicate AST. Each row is
  classified (`verified-rw` … `unknown`) and linked to Microsoft documentation
  and lab evidence. No row is `verified-rw` without Windows and endpoint
  evidence.
- Plan 021 WP-4: reference estates and evidence schema
  (`docs/plan-021/reference-estates-and-evidence.md`) — the provisional Windows
  target matrix (WS2019/2022/2025 + Win11; Win10 behind an ESU decision), the
  ADMX/ADML licensing classification rules, the redaction contract enforced by
  the identifier gate, the versioned evidence-pack JSON schema, and the
  negative/downgrade fixture requirements.
- Plan 021 WP-4: public matrix generator (`scripts/generate_public_matrix.py`
  and `src/gpo_studio/evidence.py`) — loads versioned evidence packs, refuses
  to derive claims from packs whose redaction or licensing gates are
  unsatisfied, and derives a public capability matrix containing only claims
  backed by passing evidence. A `verified-rw` claim requires both a passing
  Windows-side and a passing endpoint record.

### Changed

- Plan 033: lane verdicts now check what they claim to check. An adversarial
  review round (three reviewers, hazard-scoped, one cross-lineage) found that
  WP-2 and WP-3 graded themselves against the copy of `expected.json` the guest
  returned rather than the candidate the controller built — which also made two
  of WP-2's named checks structurally unfalsifiable — and that WP-1B, the lane
  that qualified the estate, had no environment gate at all. Both lanes now take
  `--candidate-root` and carry a `candidate_delivered_intact` check; WP-1B gates
  on `FROZEN_ENVIRONMENT` like the others. Every run now owns a private
  directory tree on the guest, so concurrent runs on one guest can no longer
  select each other's evidence; `cleanup_succeeded` means the GPO was removed or
  an independent enumeration shows nothing by that name; orphaned GPOs are
  reaped and the reap is recorded; and two fail-open defaults
  (`native_shape_findings` absent, `check_git=False`) are closed.
- Plan 033: **every evidence lane now runs against the disposable evidence
  estate over PowerShell Direct, and the SSH transport is retired.** WP-0, WP-2
  and WP-3 were ported alongside WP-1B and the endpoint lane, each with its own
  qualification run on the estate (recorded in the Qualified environments table
  in `docs/plan-033/environment-spec.md`, with committed verdicts and evidence
  tags). WP-0's certification, whose commit had been orphaned by a squash merge,
  is re-earned on a commit that resolves. Lane finalizers now check the recorded
  environment against `FROZEN_ENVIRONMENT` rather than private copies of the
  profile; WP-2 had not been checking its environment at all, and WP-3's copy
  had drifted into pinning an exact PowerShell servicing revision and gating on
  an LGPO hash the 2026-07-29 re-freeze had already removed.
- Plan 022 closed — REVIEW AND REFINE gate passed 2026-07-25
  (`docs/plan-022/gate-decision-2026-07-25.md`), with ADMX parser fixes and
  code hardening.
- Adopted `ruff` 0.16 and its expanded default rule set.
- Documentation: corrected the recorded status of Plans 021 and 023–032, which
  claimed `proposed (post-1.0)` while their implementations were already
  committed. Each now records whether its domain layer is surfaced and whether
  it carries Windows evidence. The capability matrix and README gained an
  explicit inventory of landed-but-unreachable modules, so the matrix again
  matches what `src/` contains.
- Documentation: closed out pre-release status language in `SECURITY.md` and
  Plans 017/019/020, wrote the 1.0.x support/compatibility/deprecation
  policy, and refined Plan 021 with a provisional target matrix, corpus
  licensing/redaction rules, and a pre-review spike boundary.
- Risk-based coverage floors now include `src/gpo_studio/evidence.py` (90%).
- The static safety gate now scopes forbidden-import categories to the **web
  process** — the modules transitively reachable from `api.py` — which is what
  the charter actually constrains, rather than to the `src/` directory. A
  category exemption may be granted to lab or release tooling that never runs
  in a request path, and `scripts/check_safety.py` fails if an exempt module
  ever becomes reachable from `api.py`, so an exemption cannot silently widen
  into a charter breach.

### Removed

- `scripts/windows-oracle/remote-run.ps1`, the scheduled-task launcher, and
  every lane's SSH branch. The launcher existed only to obtain a logon token an
  SSH non-interactive session cannot provide, and it took the credential as a
  `schtasks /RP` argument — transient, but decodable by a privileged observer on
  the host for as long as the task existed. PowerShell Direct carries the
  credential through the hypervisor and needs no launcher, so removing it is a
  security improvement rather than cleanup. Certifications produced on the
  retired transport are not retracted, but their evidence packs can no longer be
  re-verified in this tree, and `build_harness_inputs` reports that explicitly
  instead of defaulting to a file set that no longer exists.

### Fixed

- WI-044: a GPO carrying a **deny** security filter advertised its PowerShell
  plan and Studio export bundle as available and then refused both downloads
  with HTTP 422. WI-041's refusal is correct and is unchanged; what was missing
  was that `artifact_capabilities` derived availability from `validate_gpo`,
  which has no deny rule. The condition now lives once, in
  `export.plan_refusal()`, which both the export path and the capability
  payload consult — so the operator is told up front, with the reason, instead
  of discovering it by pressing a button. **Surfaced** (API + browser
  application).
- WI-046: the same defect as WI-044, one capability entry along — a GPO
  carrying a **GPP Registry** preference advertised `gpmc_export` as available
  and then refused the native backup with `unsupported_native_gpp_extension`.
  Native backup covers four GPP families and `Registry` is not one of them,
  while neither `validate_gpo` nor the preserved-content count could see it.
  `export.native_backup_refusal()` now derives the advertisement by running the
  refusing code rather than restating its conditions. **Surfaced** (API +
  browser application).
- WI-045: a committed lane verdict binds its harness files by SHA-256, and no
  test checked that those hashes still matched the tree. The RSOP verdicts had
  twice been re-run for exactly this reason, both times caught by a person
  rather than by CI. Live certifications are now hash-checked against the
  working tree, with deliberately retained history enumerated in
  `RETIRED_VERDICTS` and a control that fails if a retired verdict still
  matches — so the exemption list cannot be used to silence the check. Lab
  tooling; no operator-facing change.
- `jsonschema` was declared only as a uv dependency group, so `uv sync`
  installed it locally while CI's `pip install -e '.[dev]'` did not, and the
  Plan 033 WP-1A fixture tests failed on CI with `ModuleNotFoundError`. It is
  now declared in the `dev` extra and the duplicate group was removed, leaving
  one source of truth for development dependencies.
- `oracle_evidence.py` imports `subprocess` to shell out to `git` for evidence
  provenance, which violated the static safety gate's blanket ban and broke
  the `static-safety` CI job. The module is lab tooling and is unreachable
  from the web process; it is now covered by a reachability-enforced exemption
  rather than by weakening the ban.

## [1.0.0] - 2026-07-18

### Changed

- Promoted `1.0.0rc3` after the complete Windows NVDA acceptance journey
  passed in Edge and the Firefox ESR smoke journey passed. This promotion
  contains no application-behavior changes from the tested candidate.

## [1.0.0-rc.3] - 2026-07-18

### Fixed

- JavaScript modules are now served as `text/javascript` on Windows regardless
  of the machine's MIME registry. Previously, a `text/plain` association made
  browsers reject every module under the application's `nosniff` policy,
  leaving all browser controls inert.
- Added a GPO Studio favicon.

## [1.0.0-rc.2] - 2026-07-18

### Fixed

- CycloneDX release SBOMs now receive a deterministic UUID serial number before
  GitHub attestation. The reproducible generator intentionally omitted this
  optional field, but GitHub's attestation parser requires it. The workflow now
  uses the current pinned `actions/attest` interface directly.

## [1.0.0-rc.1] - 2026-07-18

### Added

#### Capability contract and canonical model (Plan 015)

- Capability contract with explicit states: `supported`, `preview`,
  `preserved`, `blocked`, and `out of scope`. Replaces the stale roadmap
  table. Per-action fidelity documented for authoring, import, export,
  PowerShell plan, diff, and Windows-lab verification.
- Split semantic hashes: `policy_semantic_sha256` covers every field that
  changes effective policy or publication intent; `review_model_sha256`
  additionally covers review-relevant annotations and preserved CSE
  metadata.
- Exhaustive validation with `typing.assert_never()` dispatch on closed
  variant sets, so adding a new enum or kind fails the type check at every
  unhandled site.
- Complete two-way and three-way diff for GPP collections, ILT predicates,
  CSE metadata, side enablement, domain, and GPO-level metadata. Stable
  identities for GPP elements; link conflict detection in three-way diff.
- Golden vectors for canonical digests so other implementations can
  reproduce them.
- Stable issue codes and field paths returned by validation for browser
  field mapping.
- `ready` transition guarded: a GPO cannot enter it with validation errors,
  unknown CSE content, unresolved conflicts, or unsupported preview content.

#### GPP end-to-end authoring (Plan 016)

- GPP Groups and Registry authoring API with optimistic-concurrency CRUD
  endpoints under `/api/gpos/{guid}/preferences/...`.
- Browser editors for GPP Groups (action, members, remove-all flags,
  description) and GPP Registry (action, key, typed values) with inline
  sub-editors.
- ILT predicate editor supporting six types: `ou`, `group`, `registry`,
  `ip_range`, `environment`, `wmi_query`, with negation and AND combination.
- Plain-language ILT preview beside the serialized structure.
- Unknown XML attributes, unknown child elements, and unknown ILT predicate
  types preserved losslessly through import/export round-trips.
- Typed Pydantic request/response models and OpenAPI examples for every
  supported GPP action and value type.

#### Windows and GPMC interoperability (Plan 017)

- Versioned synthetic compatibility corpus covering all registry types,
  deletes, side state, link and security shapes, WMI, GPP Groups and
  Registry actions, all ILT predicates, Unicode, unknown content, malformed
  inputs, cpassword, migration tables, and partial or corrupt backups.
- Import conformance tests comparing normalized Studio model to expected
  semantics field by field.
- PowerShell plan validator with closed allowlist checking structure,
  assignment ordering, command shapes, pipes, semicolons, backticks,
  dangerous aliases, and case-insensitive cmdlet spelling.
- Three adversarial review rounds fixing real bypasses in multiline quoted
  strings, case-insensitive PowerShell names and aliases, and user-scope
  GPP coverage.
- WP-5 Windows lab validation on Windows Server 2025: all 12
  conformance-corpus fixtures exercised through their PowerShell plans on a
  domain controller (all six registry types, deletes, side enablement,
  idempotency, `Backup-GPO`). Sanitized, hash-pinned evidence report
  (`docs/release-evidence-report.json` +
  `scripts/generate_evidence_report.py`), capability-matrix Win-lab column
  promotions, and a root-cause diagnosis of the `Import-GPO` `Backup.xml`
  v2.0 incompatibility recorded as a known issue.

#### Workspace and runtime hardening (Plan 018)

- Versioned workspace schema with forward-only, transactional migrations,
  preflight checks, and backup before any destructive migration. Unknown
  newer schemas refused with an actionable error.
- CLI commands: `workspace check` (quick and full integrity), `workspace
  backup` (SQLite online backup API with WAL checkpoint), and `workspace
  restore` (crash-safe with rollback, retains old database).
- Atomic metadata sidecar recording schema version, application version,
  GPO count, revision count, and source/backup SHA-256 digests.
- Startup quick-check with health degradation and `/api/workspace/integrity`
  endpoint.
- Bounded untrusted input: total bytes, file count, directory depth, XML
  element count, text/attribute length, GPO count, PReg record count,
  `REG_MULTI_SZ` item count, and per-file size limits on every import path.
- Race-resistant file handling on POSIX (openat) and Windows (NtOpenFile
  with RootDirectory walk and identity verification).
- Loopback binding enforced by default. Non-loopback bind requires
  `GPO_STUDIO_UNSAFE_BIND=1`.
- Host header and mutation Origin validation to reduce DNS-rebinding abuse.
- Content-Security-Policy, `X-Content-Type-Options`, conservative referrer
  policy, and cache controls on API and artifact responses.
- Structured local logs with request ID, operation, GPO GUID, revision,
  outcome, and duration. Policy values, SIDs, paths, and request bodies
  are never logged.
- Numeric resource limits: `REG_DWORD` [0, 2^32-1], `REG_QWORD`
  [0, 2^64-1], `REG_MULTI_SZ` max 10,000 items, PReg max 100,000 records,
  backup max 100 GPOs, migration table max 10 MiB, per-file max 50 MiB,
  total backup max 500 MiB, max 10,000 filesystem entries, max depth 100,
  request body max 10 MiB.

#### Browser quality and accessibility (Plan 019)

- Browser test foundation: pinned ESLint, Prettier, Vitest, Playwright,
  and axe-core toolchain. CI exercises the packaged CLI against a temporary
  real SQLite workspace in Chromium, with a Firefox smoke baseline and
  failure traces/screenshots.
- Concurrency conflict recovery UX: 409 responses retain unsaved form
  values, fetch the current revision, and offer a structured compare/reapply
  flow. No destructive change is silently retried.
- Persistent error alerts for offline, server-down, and partial-import
  states instead of relying on transient toast messages.
- Export review boundary showing both semantic digests, validation state,
  preserved content, and artifact capability before download.
- Revision-to-revision diff selection rendering all Plan 015 diff kinds.
- Deterministic inert text policy report suitable for code review or change
  tickets, with no active content.
- Archived import detection: edit actions disabled, explicit fork path
  required before editing.
- GPP clone, atomic reorder, per-item revision restore, and destructive
  confirmation dialogs.
- Accessibility: semantic keyboard tabs, labelled and focus-managed
  dialogs, field-error relationships, persistent announcements, visible
  focus, target sizing, forced-colors and reduced-motion handling, narrow
  reflow. Automated axe checks report no serious or critical violations in
  covered primary states.
- Seven end-to-end release journeys automated in CI: raw registry
  author-review-export, ADMX configuration, estate fork and three-way
  conflict, GPMC backup import and GPP edit, security and WMI filter stale
  conflict, revision restore, and edge cases (max QWORD, Unicode, long
  values, server errors, narrow viewport).

#### Release engineering and 1.0 gates (Plan 020)

- Single version source: `pyproject.toml` reads `__version__` dynamically from
  `src/gpo_studio/__init__.py` via hatchling. Package metadata and `__version__`
  are verified consistent in CI.
- Installed-package smoke test: CI builds wheel, installs in clean Python 3.13
  venv, verifies CLI entry point, API functionality (create GPO, add settings,
  export bundle, generate plan), static UI, workspace integrity check, sdist
  excludes, and sdist required files.
- GitHub Actions pinned by immutable commit SHA with least job permissions on
  all CI jobs.
- Dependency vulnerability scanning via `pip-audit` in CI.
- SBOM generation (CycloneDX) for the shipped wheel, uploaded as artifact.
- Static safety checks (`scripts/check_safety.py`): AST-based scan for
  forbidden imports (ldap, smb, win32, subprocess, shlex), unsafe XML parsing
  (ET.fromstring/ET.parse without bounded wrapper), and publication code in the
  web process.
- Identifier gate fail-closed behavior tested (`tests/test_identifier_gate.py`).
- `SECURITY.md` security policy with supported versions, vulnerability
  reporting, threat boundaries, deployment model, and known considerations.
- `CHANGELOG.md` (this file).
- `CONTRIBUTING.md` with the complete local gate, fixture-safety rules, and
  change expectations.
- `docs/installation.md` covering installation, configuration, data location,
  privacy, troubleshooting, Windows-lab compatibility, and a five-minute
  guided workflow.
- `docs/release-evidence.md` release evidence manifest with test summaries,
  Windows lab report, and known issues.
- A limited Windows smoke run exercised generated-plan GPO creation, DWORD and
  string registry commands, and side status. It found the empty-comment defect
  below, but does not satisfy the per-capability evidence matrix; all rows
  remain pending.
- Risk-based branch-coverage floors, bounded parser/codec properties, production
  dependency vulnerability and license checks, history secret scanning,
  reproducible builds, sdist installation, and an upgrade/rollback rehearsal.
- Tag-triggered release workflow producing checksums, CycloneDX SBOM, GitHub
  provenance/SBOM attestations, and exact-artifact installation tests. The
  sanitized Windows lab evidence report is attached to each release and
  covered by the checksums and attestation.
- Separate fail-closed publication gates for prerelease candidates and the
  final release: an RC can be published as immutable test material while the
  final tag still requires an explicitly approved evidence manifest. Attached
  evidence resolves the tagged commit and wheel, sdist, and SBOM hashes.
- `docs/windows-quickstart.md`: single-operator Windows installation guide
  requiring no Git, `uv`, IIS, or service installation.
- `docs/nvda-validation-runbook.md`: scripted manual NVDA screen-reader
  session for the open Plan 019 acceptance gate.
- Plan 032 (hardened hosted control plane) authored as the executable plan
  for Plan 001 Phase 3, sequenced before Plan 030 controlled publication.

### Changed

- DWORD and QWORD request values are represented as validated decimal strings
  at the JSON boundary, then converted to Python integers after range
  checking. Prevents browser `Number` precision loss for QWORD values
  above 2^53-1. Same contract applied to ADMX decimal and enum elements.
- Mutation validation centralized so API and store callers cannot diverge.
- GPP Registry model uses a one-value-per-item invariant matching the
  MS-GPPREF one-element-per-item model. Each `<Registry>` element maps to
  exactly one domain object with one value, one UID, one ILT filter, and
  one set of element metadata.
- Unknown CSE content is inventoried (file path, SHA-256 hash, size) and
  included in `review_model_sha256`, but GPMC backup export is blocked when
  unknown CSE content is present because the bytes cannot be faithfully
  reproduced.
- Identifier gate promoted to a required CI check with tested fail-closed
  behavior.
- Capability documentation now matches executable endpoints and export
  behavior. The roadmap is superseded by the capability matrix.
- PowerShell plan accuracy documented: registry values, links, security
  filtering, and side status are actionable; WMI filter assignment and GPP
  content are not applied by the plan and are included in GPMC backup
  export only.

### Security

- `cpassword` attributes structurally detected and rejected at every
  boundary (GPMC backup import, Studio bundle export, GPMC backup export,
  authoring). Detector covers namespace-qualified variants (e.g.
  `x:cpassword`) and mixed-case forms.
- Non-loopback binding refused without `GPO_STUDIO_UNSAFE_BIND=1`
  acknowledgment. The CLI exits with an explanatory error.
- XML entity declarations rejected rather than expanded (billion-laughs
  protection) on all XML parsers.
- Symlink rejection and path-traversal guards enforced on all archive and
  inbox import paths.
- Request body size streaming enforced with a 10 MiB ceiling.
- Logs and error bodies sanitized: policy values, SIDs, paths, and request
  bodies are never logged. Error messages do not leak absolute filesystem
  paths or SQL.
- PowerShell plan validated through a closed allowlist before execution,
  rejecting unexpected command shapes, aliases, backticks, and
  case-insensitive cmdlet variants.
- Claimed actor identity is untrusted in 1.0 and must never be treated as
  authenticated audit identity.

### Fixed

- GPP and ILT collection changes now update `policy_semantic_sha256`.
  Previously, modifying a GPP collection did not change the semantic hash,
  making it unusable as a review or approval boundary.
- Link and GPP concurrent edits produce three-way conflicts rather than
  silent merges.
- Max QWORD (2^64-1) round-trips from browser-shaped JSON without precision
  loss. Previously, browser `Number` serialization truncated values above
  2^53-1.
- Stale revision mutations fail with HTTP 409 instead of silently
  overwriting. Optimistic concurrency (`expected_revision`) enforced
  consistently.
- Legacy snapshot loading and metadata precedence corrected for pre-018
  workspace imports.
- Multi-string (`REG_MULTI_SZ`) browser rendering and newline splitting
  fixed; report values rendered as human-readable semicolon-separated text
  instead of Python representation syntax.
- GPP reorder conflict detection in two-way and three-way diff.
- GPP collection validated before persisting imported GPO content.
- Root-level XML attributes and unknown root children on `<Groups>` and
  `<RegistrySettings>` preserved through import/export round-trips.
- ILT predicate interleaving order of typed and unknown predicates
  preserved through round-trips.
- `cpassword` namespace-qualified bypass closed after adversarial review.
- GPP reorder kind narrowed to a `Literal` with regression test proving
  invalid kinds never enter the mutation transaction.
- Identical revision comparisons rejected before either revision is loaded.
- GPP module shared state cleared on dialog close, preventing cancel-cycle
  leaks.
- Generated PowerShell plan emitted `New-GPO -Comment ''` when GPO had no
  description, causing a validation error (New-GPO requires non-empty
  comment). Now emits `-Comment 'Created by GPO Studio'` as fallback. Found
  during a limited Windows smoke run.
- Generated PowerShell plan emitted `REG_BINARY` values as a bare
  `[byte[]](...)` cast, which fails parameter binding under Windows
  PowerShell 5.1. Now parenthesized (`([byte[]](...))`), with
  `([byte[]]@())` for empty values. Found during the Plan 017 WP-5 lab
  validation.
- `Registry.pol` serialization omitted the UTF-16LE null terminator on key
  and value-name strings that Windows includes. Serializer now emits the
  terminator; parser strips it and remains compatible with unterminated
  legacy files. Found during the Plan 017 WP-5 lab validation.
- GPMC backup `Registry.pol` included the `HKLM\`/`HKCU\` hive prefix in
  key paths; Windows infers the hive from the `Machine`/`User` directory
  and a prefixed key produces incorrect paths on import. Found during the
  Plan 017 WP-5 lab validation.
