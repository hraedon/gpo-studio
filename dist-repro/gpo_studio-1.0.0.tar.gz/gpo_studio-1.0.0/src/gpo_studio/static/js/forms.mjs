import {state,$,$$,escapeHtml,applyPayload} from './state.mjs';
import {api,toast,audit,showPersistentError} from './api.mjs';
import {clearFormErrors,handleFormFailure,showFormErrors} from './errors.mjs';
import {loadList,renderAll,renderList,loadHistory} from './render.mjs';

export function openGpo(edit=false){
  const form=$("#gpo-form");form.reset();clearFormErrors(form);form.dataset.edit=edit?"true":"false";$("#metadata-options").hidden=!edit;
  $("#gpo-dialog-title").textContent=edit?"Edit policy details":"New GPO";$("#gpo-submit").textContent=edit?"Save changes":"Create policy";
  if(edit){const g=state.current;form.name.value=g.name;form.description.value=g.description;form.computer_enabled.checked=g.computer_enabled;form.user_enabled.checked=g.user_enabled;form.status.value=g.status;form.domain.value=g.domain||"studio.local";form.reason.value="Update policy metadata"}else form.reason.value="Create draft";
  $("#gpo-dialog").showModal();
}
export function openSetting(setting=null){
  const form=$("#setting-form");form.reset();clearFormErrors(form);state.editingSetting=setting;$("#setting-dialog-title").textContent=setting?"Edit policy setting":"Add policy setting";
  if(setting){for(const key of ["side","action","key","value_name","registry_type","comment"])form[key].value=setting[key];form.value.value=Array.isArray(setting.value)?setting.value.join("\n"):setting.value;form.reason.value="Update registry policy"}
  syncSettingForm();$("#setting-dialog").showModal();
}
export function syncSettingForm(){
  const f=$("#setting-form"),type=f.registry_type.value,side=f.side.value;$("#hive-prefix").textContent=side==="computer"?"HKLM\\":"HKCU\\";
  $("#value-help").textContent=type==="REG_MULTI_SZ"?"Enter one item per line.":type==="REG_BINARY"?"Enter hexadecimal bytes, such as 01 FF A0.":type==="REG_DWORD"||type==="REG_QWORD"?"Enter a non-negative decimal integer.":"Enter text.";
  f.value.disabled=f.action.value==="delete";
}
export function openLink(link=null){
  const form=$("#link-form");form.reset();clearFormErrors(form);state.editingLink=link;$("#link-dialog-title").textContent=link?"Edit link":"Add link";
  if(link){form.target.value=link.target;form.order.value=link.order;form.enabled.checked=link.enabled;form.enforced.checked=link.enforced;form.reason.value="Update link intent"}$("#link-dialog").showModal();
}
export function openFilter(filter=null){
  const form=$("#filter-form");form.reset();clearFormErrors(form);state.editingFilter=filter;$("#filter-dialog-title").textContent=filter?"Edit security filter":"Add security filter";
  if(filter){form.principal.value=filter.principal;form.permission.value=filter.permission;form.target_type.value=filter.target_type||"group";form.inheritable.checked=filter.inheritable;form.reason.value="Update security filter"}$("#filter-dialog").showModal();
}
export function openWmi(){
  const form=$("#wmi-form");form.reset();clearFormErrors(form);
  const w=state.current.wmi_filter;
  if(w){form.name.value=w.name;form.description.value=w.description;form.language.value=w.language;form.query.value=w.query;form.reason.value="Update WMI filter"}
  $("#wmi-dialog").showModal();
}
export async function openWmiCatalogue(){
  const list=$("#wmi-catalogue-list");list.innerHTML='<div class="table-empty">Loading…</div>';
  $("#wmi-catalogue-dialog").showModal();
  try{const data=await api("/api/wmi-filters");
    if(!data.count){list.innerHTML='<div class="table-empty">No WMI filters in catalogue. Set GPO_STUDIO_WMI_CATALOGUE to enable.</div>';return}
    list.innerHTML=data.items.map(f=>`<div class="wmi-catalogue-entry"><div><strong>${escapeHtml(f.name)}</strong>${f.description?` <small>${escapeHtml(f.description)}</small>`:''}<code class="mono">${escapeHtml(f.query)}</code></div><button type="button" data-wmi-filter-id="${escapeHtml(f.id)}">Use this</button></div>`).join("");
    $$("[data-wmi-filter-id]").forEach(btn=>btn.onclick=()=>{
      const entry=data.items.find(f=>f.id===btn.dataset.wmiFilterId);if(!entry)return;
      $("#wmi-catalogue-dialog").close();
      const form=$("#wmi-form");form.reset();clearFormErrors(form);
      form.name.value=entry.name;form.description.value=entry.description||"";form.language.value=entry.language||"WQL";form.query.value=entry.query||"";
      form.reason.value=`Apply WMI filter '${entry.name}' from catalogue`;
      $("#wmi-dialog").showModal();
    });
  }catch(error){list.innerHTML=`<div class="table-empty">${escapeHtml(error.message)}</div>`}
}
let estateParsedJson=null,estateMode='upload';
function setEstateMode(mode){estateMode=mode;$$('.estate-toggle .chip').forEach(c=>c.classList.toggle('active',c.dataset.mode===mode));$('#estate-upload-section').hidden=mode!=='upload';$('#estate-paste-section').hidden=mode!=='paste'}
export function openEstate(){
  const form=$("#estate-form");form.reset();clearFormErrors(form);
  estateParsedJson=null;setEstateMode('upload');$('#estate-file-info').hidden=true;
  $("#estate-dialog").showModal();
}
export function openFork(){
  const form=$("#fork-form");form.reset();clearFormErrors(form);
  if(state.current)form.name.value=`${state.current.name} (fork)`;
  $("#fork-dialog").showModal();
}
export function openCopySettings(){
  const form=$("#copy-settings-form");form.reset();clearFormErrors(form);
  const select=form.source_guid;select.innerHTML=state.gpos.filter(g=>g.guid!==state.current.guid).map(g=>`<option value="${escapeHtml(g.guid)}">${escapeHtml(g.name)} (r${g.revision})</option>`).join("");
  $("#copy-settings-dialog").showModal();
}
export function openComment(setting){
  const form=$("#comment-form");form.reset();clearFormErrors(form);form.setting_id.value=setting.id;
  form.comment.value=setting.comment||"";
  $("#comment-dialog").showModal();
}
function applyCurrent(data){applyPayload(data);renderAll();renderList()}
async function mutationFailure(form,error){await handleFormFailure(form,error,{onCurrent:applyCurrent})}
export function initForms(){
$("#gpo-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget;try{let data;if(f.dataset.edit==="true"){data=await api(`/api/gpos/${state.current.guid}`,{method:"PATCH",body:JSON.stringify({...audit(f.reason.value),name:f.name.value,description:f.description.value,computer_enabled:f.computer_enabled.checked,user_enabled:f.user_enabled.checked,status:f.status.value,domain:f.domain.value})})}else{data=await api("/api/gpos",{method:"POST",body:JSON.stringify({name:f.name.value,description:f.description.value,actor:"local-operator",reason:f.reason.value})})}$("#gpo-dialog").close();await loadList(data.gpo.guid);toast(f.dataset.edit==="true"?"Policy details saved":"Draft policy created")}catch(error){await mutationFailure(f,error)}};
$("#setting-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget,type=f.registry_type.value;let value=f.value.value;if(type==="REG_DWORD"||type==="REG_QWORD")value=value.trim();else if(type==="REG_MULTI_SZ")value=value.split(/\r?\n/).filter(Boolean);const setting={side:f.side.value,hive:f.side.value==="computer"?"HKLM":"HKCU",key:f.key.value.replace(/^\\+|\\+$/g,""),value_name:f.value_name.value,registry_type:type,value,action:f.action.value,comment:f.comment.value};const path=state.editingSetting?`/api/gpos/${state.current.guid}/settings/${state.editingSetting.id}`:`/api/gpos/${state.current.guid}/settings`;try{const data=await api(path,{method:state.editingSetting?"PUT":"POST",body:JSON.stringify({...audit(f.reason.value),setting})});$("#setting-dialog").close();applyCurrent(data);toast("Registry policy saved")}catch(error){await mutationFailure(f,error)}};
$("#link-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget,link={target:f.target.value,order:Number(f.order.value),enabled:f.enabled.checked,enforced:f.enforced.checked};const path=state.editingLink?`/api/gpos/${state.current.guid}/links/${state.editingLink.id}`:`/api/gpos/${state.current.guid}/links`;try{const data=await api(path,{method:state.editingLink?"PUT":"POST",body:JSON.stringify({...audit(f.reason.value),link})});$("#link-dialog").close();applyCurrent(data);toast("Link intent saved")}catch(error){await mutationFailure(f,error)}};
$("#filter-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget,filter={principal:f.principal.value,permission:f.permission.value,target_type:f.target_type.value,inheritable:f.inheritable.checked};const path=state.editingFilter?`/api/gpos/${state.current.guid}/security-filters/${state.editingFilter.id}`:`/api/gpos/${state.current.guid}/security-filters`;try{const data=await api(path,{method:state.editingFilter?"PUT":"POST",body:JSON.stringify({...audit(f.reason.value),filter})});$("#filter-dialog").close();applyCurrent(data);toast("Security filter saved")}catch(error){await mutationFailure(f,error)}};
$("#wmi-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget,wmi_filter={name:f.name.value,description:f.description.value,language:f.language.value,query:f.query.value};try{const data=await api(`/api/gpos/${state.current.guid}/wmi-filter`,{method:"PUT",body:JSON.stringify({...audit(f.reason.value),wmi_filter})});$("#wmi-dialog").close();applyCurrent(data);toast("WMI filter saved")}catch(error){await mutationFailure(f,error)}};
  $("#estate-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget;try{let body;if(estateMode==='upload'){if(!estateParsedJson){showFormErrors(f,{issues:[{message:"Choose a valid JSON file first"}]});return}body=estateParsedJson}else{body=JSON.parse(f.json.value)}const data=await api("/api/estate/import",{method:"POST",body:JSON.stringify(body)});$("#estate-dialog").close();await loadList();toast(`Imported ${data.imported} GPO(s), skipped ${data.skipped}`)}catch(error){if(error instanceof SyntaxError){showFormErrors(f,{issues:[{message:"Invalid JSON: "+error.message}]})}else{showFormErrors(f,error)}}};
  $('#estate-file').onchange=async()=>{
    const file=$('#estate-file').files[0];if(!file)return;
    const MAX_ESTATE_BYTES=5*1024*1024;
    if(file.size>MAX_ESTATE_BYTES){showFormErrors($('#estate-form'),{issues:[{message:`File too large (${(file.size/1024/1024).toFixed(1)}MB). Maximum is 5MB.`}]});return}
    const info=$('#estate-file-info');const sizeKb=(file.size/1024).toFixed(0);
    try{const text=await file.text();estateParsedJson=JSON.parse(text);info.hidden=false;info.innerHTML=`<strong>${escapeHtml(file.name)}</strong> (${sizeKb} KB)${file.size>1048576?' <span class="diff-modified">⚠ File exceeds 1 MB</span>':''}`}catch(e){estateParsedJson=null;info.hidden=false;info.innerHTML=`<strong>${escapeHtml(file.name)}</strong> (${sizeKb} KB) <span class="diff-removed">✗ Invalid JSON: ${escapeHtml(e.message)}</span>`}
  };
  $$('.estate-toggle .chip').forEach(c=>c.onclick=()=>setEstateMode(c.dataset.mode));
  $("#fork-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget;try{const data=await api(`/api/gpos/${state.current.guid}/fork`,{method:"POST",body:JSON.stringify({name:f.name.value,actor:"local-operator",reason:f.reason.value})});$("#fork-dialog").close();await loadList(data.gpo.guid);toast("Forked to draft")}catch(error){showFormErrors(f,error)}};
  $("#copy-settings-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget;const side=f.side.value||null;try{const data=await api(`/api/gpos/${state.current.guid}/copy-settings`,{method:"POST",body:JSON.stringify({...audit(f.reason.value),source_guid:f.source_guid.value,side})});$("#copy-settings-dialog").close();applyCurrent(data);toast("Settings copied")}catch(error){await mutationFailure(f,error)}};
  $("#comment-form").onsubmit=async event=>{event.preventDefault();if(event.submitter&&event.submitter.value==="cancel"){event.currentTarget.closest("dialog").close();return}const f=event.currentTarget;try{const data=await api(`/api/gpos/${state.current.guid}/settings/${f.setting_id.value}/comment`,{method:"PATCH",body:JSON.stringify({...audit(f.reason.value),comment:f.comment.value})});$("#comment-dialog").close();applyCurrent(data);toast("Comment saved")}catch(error){await mutationFailure(f,error)}};
}
export async function deleteSetting(id){if(!confirm(`Remove registry setting ${id} from ${state.current.name}? This creates a new revision.`))return;try{const data=await api(`/api/gpos/${state.current.guid}/settings/${id}`,{method:"DELETE",body:JSON.stringify({...audit("Remove registry policy")})});applyCurrent(data);toast("Setting removed")}catch(error){showPersistentError(error.message)}}
export async function deleteLink(id){const target=state.current.links.find(item=>item.id===id)?.target||id;if(!confirm(`Remove link intent for ${target} from ${state.current.name}? This creates a new revision.`))return;try{const data=await api(`/api/gpos/${state.current.guid}/links/${id}`,{method:"DELETE",body:JSON.stringify({...audit("Remove link intent")})});applyCurrent(data);toast("Link removed")}catch(error){showPersistentError(error.message)}}
export async function deleteFilter(id){const principal=state.current.security_filters.find(item=>item.id===id)?.principal||id;if(!confirm(`Remove security filter ${principal} from ${state.current.name}? This may broaden policy reach and creates a new revision.`))return;try{const data=await api(`/api/gpos/${state.current.guid}/security-filters/${id}`,{method:"DELETE",body:JSON.stringify({...audit("Remove security filter")})});applyCurrent(data);toast("Security filter removed")}catch(error){showPersistentError(error.message)}}
export async function restoreRevision(revision){if(!confirm(`Restore ${state.current.name} revision ${revision} as a new revision? Current policy content will be replaced, while history remains append-only.`))return;try{const data=await api(`/api/gpos/${state.current.guid}/revisions/${revision}/restore`,{method:"POST",body:JSON.stringify({...audit(`Restore revision ${revision}`)})});applyCurrent(data);await loadHistory();toast(`Revision ${revision} restored`)}catch(error){showPersistentError(error.message)}}
