from __future__ import annotations

import io
import zipfile
from pathlib import Path

from fastapi.testclient import TestClient

from gpo_studio.api import app
from gpo_studio.registry_pol import PolRecord, serialize
from gpo_studio.store import WorkspaceStore

_ADMX_MINIMAL = b"""<?xml version="1.0" encoding="utf-8"?>
<policyDefinitions xmlns="http://www.microsoft.com/GroupPolicy/PolicyDefinitions">
  <categories>
    <category name="SyntheticCategory" displayName="$(string.SyntheticCategory)">
      <parentCategory ref="ParentCat" />
    </category>
  </categories>
  <supportedOn>
    <definition name="Supported_Synthetic" displayName="$(string.Supported_Synthetic)" />
  </supportedOn>
  <policies>
    <policy name="SyntheticPolicy" class="Machine" key="Software\\Policies\\Synthetic"
            displayName="$(string.SyntheticPolicy)" explainText="$(string.SyntheticPolicy_Explain)"
            supportedOn="Supported_Synthetic" presentation="$(presentation.SyntheticPolicy)">
      <parentCategory ref="SyntheticCategory" />
      <supportedOn ref="Supported_Synthetic" />
      <elements>
        <boolean id="Enabled" key="Software\\Policies\\Synthetic" valueName="Enabled" />
      </elements>
      <presentation>
        <checkBox id="Enabled" refId="Enabled" label="$(string.EnableLabel)" />
      </presentation>
    </policy>
    <policy name="UserPolicy" class="User" key="Software\\Policies\\UserSynthetic"
            displayName="$(string.UserPolicy)" explainText="$(string.UserPolicy_Explain)"
            supportedOn="Supported_Synthetic" presentation="$(presentation.UserPolicy)">
      <parentCategory ref="SyntheticCategory" />
      <supportedOn ref="Supported_Synthetic" />
      <elements>
        <text id="UserSetting" key="Software\\Policies\\UserSynthetic" valueName="UserSetting" />
      </elements>
      <presentation>
        <textBox id="UserSetting" refId="UserSetting" label="$(string.UserSettingLabel)" />
      </presentation>
    </policy>
  </policies>
</policyDefinitions>"""

_ADML_MINIMAL = b"""<?xml version="1.0" encoding="utf-8"?>
<policyDefinitionResources xmlns="http://www.microsoft.com/GroupPolicy/PolicyDefinitions">
  <resources>
    <stringTable>
      <string id="SyntheticCategory">Synthetic Category</string>
      <string id="Supported_Synthetic">Synthetic OS Support</string>
      <string id="SyntheticPolicy">Synthetic Policy</string>
      <string id="SyntheticPolicy_Explain">This is a synthetic policy for testing.</string>
      <string id="UserPolicy">User Policy</string>
      <string id="UserPolicy_Explain">User-side synthetic policy.</string>
      <string id="EnableLabel">Enable</string>
      <string id="UserSettingLabel">User Setting</string>
    </stringTable>
  </resources>
</policyDefinitionResources>"""

# A policy carrying BOTH a policy-level valueName (with explicit enabled/disabled
# values) and a child element, so state transitions have something to write and
# something to clean up. _ADMX_MINIMAL's policies have no valueName at all.
_ADMX_STATEFUL = b"""<?xml version="1.0" encoding="utf-8"?>
<policyDefinitions xmlns="http://schemas.microsoft.com/GroupPolicy/2006/07/PolicyDefinitions">
  <policyNamespaces>
    <target prefix="stateful" namespace="Synthetic.Policies.Stateful" />
  </policyNamespaces>
  <categories>
    <category name="StatefulCategory" displayName="$(string.StatefulCategory)" />
  </categories>
  <supportedOn>
    <definition name="Supported_Stateful" displayName="$(string.Supported_Stateful)" />
  </supportedOn>
  <policies>
    <policy name="StatefulPolicy" class="Machine" key="Software\\Policies\\Stateful"
            displayName="$(string.StatefulPolicy)" explainText="$(string.StatefulPolicy)"
            valueName="FeatureState" presentation="$(presentation.StatefulPolicy)">
      <parentCategory ref="StatefulCategory" />
      <supportedOn ref="Supported_Stateful" />
      <enabledValue><decimal value="1" /></enabledValue>
      <disabledValue><decimal value="0" /></disabledValue>
      <elements>
        <boolean id="SubOption" valueName="SubOption" />
      </elements>
    </policy>
    <policy name="BothClassPolicy" class="Both" key="Software\\Policies\\StatefulBoth"
            displayName="$(string.BothClassPolicy)" explainText="$(string.BothClassPolicy)"
            valueName="BothState" presentation="$(presentation.BothClassPolicy)">
      <parentCategory ref="StatefulCategory" />
      <supportedOn ref="Supported_Stateful" />
      <enabledValue><decimal value="1" /></enabledValue>
      <disabledValue><decimal value="0" /></disabledValue>
    </policy>
  </policies>
</policyDefinitions>"""

_ADML_STATEFUL = b"""<?xml version="1.0" encoding="utf-8"?>
<policyDefinitionResources xmlns="http://schemas.microsoft.com/GroupPolicy/2006/07/PolicyDefinitions">
  <resources>
    <stringTable>
      <string id="StatefulCategory">Stateful Category</string>
      <string id="Supported_Stateful">Synthetic OS Support</string>
      <string id="StatefulPolicy">Stateful Policy</string>
      <string id="BothClassPolicy">Both Class Policy</string>
    </stringTable>
    <presentationTable>
      <presentation id="StatefulPolicy">
        <checkBox refId="SubOption">Sub option</checkBox>
      </presentation>
      <presentation id="BothClassPolicy">
      </presentation>
    </presentationTable>
  </resources>
</policyDefinitionResources>"""


def test_full_api_authoring_flow(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        response = client.post(
            "/api/gpos",
            json={"name": "Synthetic browser policy", "actor": "tester", "reason": "test"},
        )
        assert response.status_code == 201
        gpo = response.json()["gpo"]
        response = client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "actor": "tester",
                "reason": "add setting",
                "expected_revision": gpo["revision"],
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Test",
                    "value_name": "Enabled",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        )
        assert response.status_code == 201
        gpo = response.json()["gpo"]
        assert gpo["revision"] == 2
        assert len(gpo["settings"]) == 1
        assert client.get(f"/api/gpos/{gpo['guid']}/export.zip").status_code == 200
        assert len(client.get(f"/api/gpos/{gpo['guid']}/revisions").json()["items"]) == 2


def test_api_rejects_side_hive_mismatch_and_stale_revision(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Synthetic policy"}).json()["gpo"]
        invalid = client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "expected_revision": 1,
                "setting": {
                    "side": "user",
                    "hive": "HKLM",
                    "key": "Software\\Policies\\Synthetic",
                    "value_name": "X",
                    "registry_type": "REG_SZ",
                    "value": "x",
                },
            },
        )
        assert invalid.status_code == 422
        assert invalid.json()["error"]["issues"][0]["code"] == "side_hive_mismatch"
        client.patch(
            f"/api/gpos/{gpo['guid']}",
            json={
                "expected_revision": 1,
                "name": gpo["name"],
                "description": "changed",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
            },
        )
        stale = client.patch(
            f"/api/gpos/{gpo['guid']}",
            json={
                "expected_revision": 1,
                "name": gpo["name"],
                "description": "stale",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
            },
        )
        assert stale.status_code == 409


def test_semantic_hash_in_response(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/gpos", json={"name": "Hash test policy"})
        assert resp.status_code == 201
        data = resp.json()
        assert "semantic_sha256" not in data
        assert "policy_semantic_sha256" in data
        assert "review_model_sha256" in data
        assert len(data["policy_semantic_sha256"]) == 64
        assert len(data["review_model_sha256"]) == 64
        guid = data["gpo"]["guid"]
        rev = data["gpo"]["revision"]
        resp = client.post(
            f"/api/gpos/{guid}/settings",
            json={
                "expected_revision": rev,
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Test",
                    "value_name": "Enabled",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        )
        assert resp.status_code == 201
        new_hash = resp.json()["policy_semantic_sha256"]
        assert new_hash != data["policy_semantic_sha256"]


def test_two_way_diff(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Diff test"}).json()["gpo"]
        setting_resp = client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "expected_revision": 1,
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Diff",
                    "value_name": "SettingA",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        )
        assert setting_resp.status_code == 201
        diff = client.get(f"/api/gpos/{gpo['guid']}/diff?against_revision=1")
        assert diff.status_code == 200
        result = diff.json()
        assert len(result["settings"]) == 1
        assert result["settings"][0]["kind"] == "added"


def test_two_way_diff_identical(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Diff identical"}).json()["gpo"]
        diff = client.get(f"/api/gpos/{gpo['guid']}/diff?against_revision=1")
        assert diff.status_code == 200
        result = diff.json()
        assert result["settings"] == []
        assert result["links"] == []


def test_three_way_diff(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        base = client.post("/api/gpos", json={"name": "Baseline"}).json()["gpo"]
        draft = client.post("/api/gpos", json={"name": "Draft"}).json()["gpo"]
        observed = client.post("/api/gpos", json={"name": "Observed"}).json()["gpo"]
        resp = client.post(
            "/api/diff",
            json={
                "baseline": base["guid"],
                "draft": draft["guid"],
                "observed": observed["guid"],
            },
        )
        assert resp.status_code == 200
        result = resp.json()
        assert "settings" in result
        assert "links" in result
        assert "conflicts" in result


_MANIFEST_XML = b"""<?xml version="1.0" encoding="utf-8"?>
<BackupInstances xmlns="http://www.microsoft.com/GroupPolicy/Types">
  <BackupInstance>
    <BackupTime>2026-01-01T00:00:00</BackupTime>
    <ID>backup-001</ID>
    <GPO>
      <Identifier>11111111-2222-3333-4444-555555555555</Identifier>
      <DisplayName>Imported Policy</DisplayName>
      <Domain>example.test</Domain>
    </GPO>
  </BackupInstance>
</BackupInstances>"""


def test_backup_import(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    machine_dir = gpo_dir / "Machine"
    user_dir = gpo_dir / "User"
    machine_dir.mkdir(parents=True)
    user_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    machine_pol = serialize([
        PolRecord(key=r"Software\Policies\Test", value_name="Enabled",
                  registry_type="REG_DWORD", value=1),
    ])
    (machine_dir / "Registry.pol").write_bytes(machine_pol)
    (user_dir / "Registry.pol").write_bytes(b"PReg\x01\x00\x00\x00")

    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "Import test backup",
        })
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["name"] == "Imported Policy"
        assert gpo["source_guid"] == "11111111-2222-3333-4444-555555555555"
        assert len(gpo["settings"]) == 1
        assert gpo["settings"][0]["key"] == r"Software\Policies\Test"
        assert gpo["settings"][0]["value"] == "1"


def test_backup_import_nonexistent_dir(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(tmp_path / "nonexistent"),
        })
        assert resp.status_code == 422


def test_gpmc_backup_export(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Export test"}).json()["gpo"]
        setting_resp = client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "expected_revision": 1,
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Test",
                    "value_name": "Enabled",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        )
        assert setting_resp.status_code == 201
        resp = client.get(f"/api/gpos/{gpo['guid']}/gpmc-backup")
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "application/zip"
        with zipfile.ZipFile(io.BytesIO(resp.content)) as archive:
            names = archive.namelist()
            assert "manifest.xml" in names
            from gpo_studio.backup import parse_manifest
            backup = parse_manifest(archive.read("manifest.xml"))
            backup_id = backup.backup_id
            assert f"{backup_id}/Backup.xml" in names
            assert f"{backup_id}/bkupInfo.xml" in names
            assert (
                f"{backup_id}/DomainSysvol/GPO/Machine/registry.pol" in names
            )
            assert not any(name.endswith("/gpreport.xml") for name in names)
            assert not any(name.endswith("/DomainController.xml") for name in names)
            assert backup.gpos[0].display_name == "Export test"


def test_gpmc_backup_roundtrip(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Roundtrip test"}).json()["gpo"]
        client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "expected_revision": 1,
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Roundtrip",
                    "value_name": "SettingA",
                    "registry_type": "REG_DWORD",
                    "value": "42",
                },
            },
        )
        resp = client.get(f"/api/gpos/{gpo['guid']}/gpmc-backup")
        assert resp.status_code == 200
        backup_dir = tmp_path / "gpmc_backup"
        backup_dir.mkdir()
        with zipfile.ZipFile(io.BytesIO(resp.content)) as archive:
            archive.extractall(backup_dir)
        store.close()
        app.state.store = WorkspaceStore(tmp_path / "api2.db")
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "Round-trip import",
        })
        assert resp.status_code == 201
        imported = resp.json()["gpo"]
        assert len(imported["settings"]) == 1
        assert imported["settings"][0]["key"] == r"Software\Policies\Roundtrip"
        assert imported["settings"][0]["value"] == "42"


def test_gpmc_backup_deterministic(tmp_path) -> None:
    from gpo_studio.export import gpmc_backup_bundle
    from gpo_studio.model import GPO, RegistrySetting
    gpo = GPO(
        guid="11111111-2222-3333-4444-555555555555",
        name="Deterministic test",
        settings=(
            RegistrySetting(
                id="s1", side="computer", hive="HKLM",
                key=r"Software\Policies\Test", value_name="V",
                registry_type="REG_DWORD", value=1,
            ),
        ),
    )
    assert gpmc_backup_bundle(gpo) == gpmc_backup_bundle(gpo)


def _setup_admx_env(tmp_path, monkeypatch, admx_dir_name: str = "admx"):
    admx_dir = tmp_path / admx_dir_name
    admx_dir.mkdir()
    (admx_dir / "test.admx").write_bytes(_ADMX_MINIMAL)
    (admx_dir / "test.adml").write_bytes(_ADML_MINIMAL)
    monkeypatch.setenv("GPO_STUDIO_ADMX_DIR", str(admx_dir))
    if hasattr(app.state, "admx_catalogue"):
        del app.state.admx_catalogue
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False


def test_admx_search_returns_results(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/search?q=Synthetic")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] > 0
        assert any(p["id"] == "SyntheticPolicy" for p in data["items"])


def test_admx_search_empty_query(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/search")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 2


def test_admx_policy_detail(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/policies/SyntheticPolicy")
        assert resp.status_code == 200
        policy = resp.json()
        assert policy["id"] == "SyntheticPolicy"
        assert policy["display_name"] == "Synthetic Policy"
        assert len(policy["elements"]) > 0
        assert len(policy["presentation"]) > 0
        not_found = client.get("/api/admx/policies/Nonexistent")
        assert not_found.status_code == 404


def _setup_real_shape_admx_env(tmp_path, monkeypatch):
    """Point the app at the real-shaped fixtures, which collide on policy name."""
    fixtures = Path(__file__).parent / "fixtures" / "admx_real_shape"
    monkeypatch.setenv("GPO_STUDIO_ADMX_DIR", str(fixtures))
    if hasattr(app.state, "admx_catalogue"):
        del app.state.admx_catalogue
    app.state.store = WorkspaceStore(tmp_path / "api.db")
    app.state.owns_store = False


def test_admx_search_exposes_qualified_id(tmp_path, monkeypatch) -> None:
    _setup_real_shape_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        data = client.get("/api/admx/search?q=SharedPolicyName").json()
        qualified = {p["qualified_id"] for p in data["items"]}
        assert qualified == {
            "Synthetic.Policies.VendorA:SharedPolicyName",
            "Synthetic.Policies.VendorB:SharedPolicyName",
        }


def test_admx_detail_by_qualified_id(tmp_path, monkeypatch) -> None:
    _setup_real_shape_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get(
            "/api/admx/policies/Synthetic.Policies.VendorA%3ASharedPolicyName"
        )
        assert resp.status_code == 200
        policy = resp.json()
        assert policy["namespace"] == "Synthetic.Policies.VendorA"
        assert policy["key"] == "Software\\Policies\\SyntheticVendorA\\Feature"
        # Presentation comes from the ADML presentationTable, not inline ADMX.
        assert [p["kind"] for p in policy["presentation"]] == [
            "checkbox",
            "decimal",
            "text",
            "list",
        ]


def test_admx_detail_ambiguous_name_is_409_not_arbitrary(
    tmp_path, monkeypatch
) -> None:
    _setup_real_shape_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/policies/SharedPolicyName")
        assert resp.status_code == 409
        error = resp.json()["error"]
        assert error["code"] == "ambiguous_policy"
        assert error["candidates"] == [
            "Synthetic.Policies.VendorA:SharedPolicyName",
            "Synthetic.Policies.VendorB:SharedPolicyName",
        ]


def test_admx_detail_unambiguous_bare_name_still_works(tmp_path, monkeypatch) -> None:
    _setup_real_shape_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/policies/VendorBOnlyPolicy")
        assert resp.status_code == 200
        assert resp.json()["namespace"] == "Synthetic.Policies.VendorB"


def _setup_stateful_admx_env(tmp_path, monkeypatch):
    admx_dir = tmp_path / "stateful"
    admx_dir.mkdir()
    (admx_dir / "stateful.admx").write_bytes(_ADMX_STATEFUL)
    (admx_dir / "stateful.adml").write_bytes(_ADML_STATEFUL)
    monkeypatch.setenv("GPO_STUDIO_ADMX_DIR", str(admx_dir))
    if hasattr(app.state, "admx_catalogue"):
        del app.state.admx_catalogue
    app.state.store = WorkspaceStore(tmp_path / "api.db")
    app.state.owns_store = False


_STATEFUL_ID = "Synthetic.Policies.Stateful%3AStatefulPolicy"


def _configure(client, gpo, *, state: str, values: dict | None = None):
    return client.post(
        f"/api/admx/policies/{_STATEFUL_ID}/configure",
        json={
            "gpo_guid": gpo["guid"],
            "side": "computer",
            "values": values or {},
            "state": state,
            "expected_revision": gpo["revision"],
            "actor": "tester",
            "reason": f"Set {state}",
        },
    )


def test_configure_policy_enabled_writes_state_and_element(
    tmp_path, monkeypatch
) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        resp = _configure(client, gpo, state="enabled", values={"SubOption": True})
        assert resp.status_code == 200
        settings = resp.json()["gpo"]["settings"]
        assert {s["value_name"] for s in settings} == {"FeatureState", "SubOption"}


def test_configure_policy_disabled_writes_the_disabled_value(
    tmp_path, monkeypatch
) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        settings = _configure(client, gpo, state="disabled").json()["gpo"]["settings"]
        # Disabling also deletes every element value name, matching gpedit
        # (WI-020, lab-verified 2026-07-27): Windows writes one **del. record
        # per <elements> child alongside the policy's own disabled value.
        by_name = {item["value_name"]: item for item in settings}
        assert by_name["FeatureState"]["value"] == "0"
        assert by_name["FeatureState"]["action"] == "set"
        assert by_name["SubOption"]["action"] == "delete"


def test_enabled_to_disabled_drops_the_element_settings(tmp_path, monkeypatch) -> None:
    # The transition regression: put_settings upserts by id, so without a
    # prefix-scoped replace the Enabled element value would survive alongside
    # the Disabled state value and both would land in Registry.pol.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        gpo = _configure(client, gpo, state="enabled", values={"SubOption": True}).json()["gpo"]
        assert len(gpo["settings"]) == 2
        settings = _configure(client, gpo, state="disabled").json()["gpo"]["settings"]
        # The Enabled element value must not survive as a stale SET. Since
        # WI-020 it is replaced by an explicit DELETE rather than vanishing,
        # which is what gpedit writes; the regression this guards is a
        # surviving "set", so assert the action, not mere absence.
        by_name = {item["value_name"]: item for item in settings}
        assert by_name["FeatureState"]["value"] == "0"
        assert by_name["SubOption"]["action"] == "delete"


def test_not_configured_removes_the_settings_rather_than_no_op(
    tmp_path, monkeypatch
) -> None:
    # An empty settings list through put_settings is a silent no-op, which would
    # report success while leaving the policy configured.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        gpo = _configure(client, gpo, state="enabled", values={"SubOption": True}).json()["gpo"]
        assert gpo["settings"]
        resp = _configure(client, gpo, state="not_configured")
        assert resp.status_code == 200
        assert resp.json()["gpo"]["settings"] == []


def test_not_configured_leaves_other_policies_alone(tmp_path, monkeypatch) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        gpo = _configure(client, gpo, state="enabled", values={"SubOption": True}).json()["gpo"]
        # An unrelated hand-authored setting must survive the removal.
        gpo = client.put(
            f"/api/gpos/{gpo['guid']}/settings/unrelated",
            json={
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Other",
                    "value_name": "Keep",
                    "registry_type": "REG_DWORD",
                    "value": "7",
                },
                "expected_revision": gpo["revision"],
            },
        ).json()["gpo"]
        settings = _configure(client, gpo, state="not_configured").json()["gpo"]["settings"]
        assert [s["value_name"] for s in settings] == ["Keep"]


def test_element_values_with_disabled_state_are_rejected(tmp_path, monkeypatch) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        resp = _configure(client, gpo, state="disabled", values={"SubOption": True})
        assert resp.status_code == 422
        assert "SubOption" in resp.json()["error"]["issues"][0]["message"]


def test_unknown_state_is_rejected(tmp_path, monkeypatch) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        assert _configure(client, gpo, state="sideways").status_code == 422


def test_state_defaults_to_enabled_for_existing_clients(tmp_path, monkeypatch) -> None:
    # Clients written before the state field must keep working unchanged.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "States"}).json()["gpo"]
        resp = client.post(
            f"/api/admx/policies/{_STATEFUL_ID}/configure",
            json={
                "gpo_guid": gpo["guid"],
                "side": "computer",
                "values": {"SubOption": True},
                "expected_revision": gpo["revision"],
            },
        )
        assert resp.status_code == 200
        assert {s["value_name"] for s in resp.json()["gpo"]["settings"]} == {
            "FeatureState",
            "SubOption",
        }


def test_admx_categories(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.get("/api/admx/categories")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] > 0
        assert any(c["id"] == "SyntheticCategory" for c in data["items"])


def test_admx_no_directory(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_ADMX_DIR", str(tmp_path / "nonexistent"))
    if hasattr(app.state, "admx_catalogue"):
        del app.state.admx_catalogue
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        health = client.get("/api/health")
        assert health.json()["admx_loaded"] is False
        search = client.get("/api/admx/search")
        assert search.status_code == 200
        assert search.json()["count"] == 0
        cats = client.get("/api/admx/categories")
        assert cats.status_code == 200
        assert cats.json()["count"] == 0


def test_gpmc_backup_rejected_with_cse_metadata(tmp_path) -> None:
    from gpo_studio.model import CseMetadataEntry
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = store.create_gpo(
            "CSE test", identity="tester", reason="test",
            cse_metadata=(CseMetadataEntry(guid="{unknown-guid}", side="machine"),),
        )
        resp = client.get(f"/api/gpos/{gpo.guid}/gpmc-backup")
        assert resp.status_code == 422
        assert resp.json()["error"]["issues"][0]["code"] == "unknown_cse_content"


def test_three_way_diff_identical(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Identical 3-way"}).json()["gpo"]
        resp = client.post("/api/diff", json={
            "baseline": gpo["guid"],
            "draft": gpo["guid"],
            "observed": gpo["guid"],
        })
        assert resp.status_code == 200
        result = resp.json()
        assert result["settings"] == []
        assert result["conflicts"] == []


def test_ad_hoc_diff_malformed_dict(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/diff", json={
            "baseline": {"missing": "fields"},
            "draft": {"missing": "fields"},
            "observed": {"missing": "fields"},
        })
        assert resp.status_code == 422


def test_backup_import_no_registry_pol(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    gpo_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={"path": str(backup_dir)})
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["settings"] == []


def test_backup_import_not_a_directory(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={"path": str(tmp_path / "nonexistent")})
        assert resp.status_code == 422


def test_configure_policy_boolean(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Config target"}).json()["gpo"]
        resp = client.post("/api/admx/policies/SyntheticPolicy/configure", json={
            "gpo_guid": gpo["guid"],
            "side": "computer",
            "values": {"Enabled": True},
            "expected_revision": gpo["revision"],
            "actor": "tester",
            "reason": "Configure policy",
        })
        assert resp.status_code == 200
        updated = resp.json()["gpo"]
        assert len(updated["settings"]) == 1
        assert updated["settings"][0]["registry_type"] == "REG_DWORD"
        assert updated["settings"][0]["value"] == "1"


def test_configure_policy_unknown_policy_404(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Target"}).json()["gpo"]
        resp = client.post("/api/admx/policies/Nonexistent/configure", json={
            "gpo_guid": gpo["guid"],
            "side": "computer",
            "values": {},
            "expected_revision": gpo["revision"],
        })
        assert resp.status_code == 404


def test_configure_policy_invalid_config_422(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Target"}).json()["gpo"]
        resp = client.post("/api/admx/policies/SyntheticPolicy/configure", json={
            "gpo_guid": gpo["guid"],
            "side": "computer",
            "values": {},
            "expected_revision": gpo["revision"],
        })
        assert resp.status_code == 422


def test_configure_policy_side_mismatch_422(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Target"}).json()["gpo"]
        resp = client.post("/api/admx/policies/SyntheticPolicy/configure", json={
            "gpo_guid": gpo["guid"],
            "side": "user",
            "values": {"Enabled": True},
            "expected_revision": gpo["revision"],
        })
        assert resp.status_code == 422


def test_configure_policy_unknown_gpo_404(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.post("/api/admx/policies/SyntheticPolicy/configure", json={
            "gpo_guid": "nonexistent-guid",
            "side": "computer",
            "values": {"Enabled": True},
            "expected_revision": 1,
        })
        assert resp.status_code == 404


def test_typed_cse_metadata_round_trip(tmp_path) -> None:
    from gpo_studio.model import CseFileEntry, CseMetadataEntry
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        cse = CseMetadataEntry(
            guid="{12345678-1234-1234-1234-123456789abc}",
            side="machine",
            files=(
                CseFileEntry(
                    relative_path="Custom/custom.xml",
                    content_hash="abc123",
                    size=100,
                ),
            ),
        )
        gpo = store.create_gpo(
            "Typed CSE test", identity="tester", reason="test",
            cse_metadata=(cse,),
        )
        resp = client.get(f"/api/gpos/{gpo.guid}")
        assert resp.status_code == 200
        cse_data = resp.json()["gpo"]["cse_metadata"]
        assert len(cse_data) == 1
        assert cse_data[0]["guid"] == "{12345678-1234-1234-1234-123456789abc}"
        assert cse_data[0]["side"] == "machine"
        assert len(cse_data[0]["files"]) == 1
        assert cse_data[0]["files"][0]["relative_path"] == "Custom/custom.xml"
        assert cse_data[0]["files"][0]["content_hash"] == "abc123"
        assert cse_data[0]["files"][0]["size"] == 100


def _create_minimal_backup(backup_dir: Path) -> None:
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    machine_dir = gpo_dir / "Machine"
    user_dir = gpo_dir / "User"
    machine_dir.mkdir(parents=True)
    user_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    machine_pol = serialize([
        PolRecord(key=r"Software\Policies\Test", value_name="Enabled",
                  registry_type="REG_DWORD", value=1),
    ])
    (machine_dir / "Registry.pol").write_bytes(machine_pol)
    (user_dir / "Registry.pol").write_bytes(b"PReg\x01\x00\x00\x00")


def test_backup_import_within_inbox(tmp_path: Path, monkeypatch) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    backup_dir = inbox_dir / "backup"
    _create_minimal_backup(backup_dir)
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "Import from inbox",
        })
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["name"] == "Imported Policy"
        assert gpo["source_guid"] == "11111111-2222-3333-4444-555555555555"


def test_backup_import_outside_inbox_rejected(tmp_path: Path, monkeypatch) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    backup_dir = tmp_path / "outside" / "backup"
    _create_minimal_backup(backup_dir)
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
        })
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert issues[0]["code"] == "path_outside_inbox"
        assert str(backup_dir) not in issues[0]["message"]


def test_backup_import_no_inbox_configured(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.delenv("GPO_STUDIO_INBOX_DIR", raising=False)
    backup_dir = tmp_path / "backup"
    _create_minimal_backup(backup_dir)
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    monkeypatch.chdir(tmp_path)
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": "backup",
        })
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["name"] == "Imported Policy"


def test_backup_import_path_traversal_rejected(tmp_path: Path, monkeypatch) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    backup_dir = tmp_path / "outside" / "backup"
    _create_minimal_backup(backup_dir)
    traversal_path = str(inbox_dir / ".." / "outside" / "backup")
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": traversal_path,
        })
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert issues[0]["code"] == "path_outside_inbox"


def test_backup_import_relative_traversal_rejected(
    tmp_path: Path, monkeypatch
) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        response = client.post(
            "/api/backups/import",
            json={"path": "../../../../etc/passwd"},
        )

    assert response.status_code == 422
    issue = response.json()["error"]["issues"][0]
    assert issue["code"] == "path_outside_inbox"
    assert "passwd" not in issue["message"]


def test_import_backup_rejects_symlinked_manifest(tmp_path: Path, monkeypatch) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    backup_dir = inbox_dir / "backup"
    _create_minimal_backup(backup_dir)

    target = tmp_path / "fake_manifest.xml"
    target.write_bytes(b"evil")
    (backup_dir / "manifest.xml").unlink()
    (backup_dir / "manifest.xml").symlink_to(target)

    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "Import symlinked backup",
        })
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert issues[0]["code"] == "symlink_in_backup"


def test_security_filter_add_edit_delete(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Security filter policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "grant apply",
                "filter": {
                    "principal": "Domain Admins",
                    "permission": "apply",
                    "inheritable": True,
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == 2
        assert len(gpo["security_filters"]) == 1
        assert gpo["security_filters"][0]["principal"] == "Domain Admins"
        assert gpo["security_filters"][0]["permission"] == "apply"

        filter_id = gpo["security_filters"][0]["id"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/security-filters/{filter_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "downgrade to read",
                "filter": {
                    "principal": "Domain Admins",
                    "permission": "read",
                    "inheritable": True,
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == 3
        assert len(gpo["security_filters"]) == 1
        assert gpo["security_filters"][0]["permission"] == "read"

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/security-filters/{filter_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "remove filter",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == 4
        assert len(gpo["security_filters"]) == 0


def test_security_filter_creates_revision(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Revision test"}
        ).json()["gpo"]
        initial_revision = gpo["revision"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add filter",
                "filter": {"principal": "Domain Users"},
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == initial_revision + 1
        revisions = client.get(
            f"/api/gpos/{gpo['guid']}/revisions"
        ).json()["items"]
        assert len(revisions) == 2


def test_security_filter_stale_revision_returns_409(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Conflict test"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": 999,
                "actor": "tester",
                "reason": "stale",
                "filter": {"principal": "Domain Admins"},
            },
        )
        assert resp.status_code == 409


def test_security_filter_with_target_type_user(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Target type policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "grant to user",
                "filter": {
                    "principal": "DOMAIN\\SvcAccount",
                    "permission": "apply",
                    "inheritable": True,
                    "target_type": "user",
                },
            },
        )
        assert resp.status_code == 201
        sf = resp.json()["gpo"]["security_filters"][0]
        assert sf["target_type"] == "user"


def test_wmi_filter_set_and_clear(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "WMI filter policy"}
        ).json()["gpo"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/wmi-filter",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "scope to workstations",
                "wmi_filter": {
                    "name": "Workstations",
                    "description": "Workstation filter",
                    "query": "SELECT * FROM Win32_ComputerSystem",
                    "language": "WQL",
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == 2
        assert gpo["wmi_filter"] is not None
        assert gpo["wmi_filter"]["name"] == "Workstations"
        assert gpo["wmi_filter"]["query"] == "SELECT * FROM Win32_ComputerSystem"

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/wmi-filter",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "clear filter",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["revision"] == 3
        assert gpo["wmi_filter"] is None


def test_domain_update_via_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "domain.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post(
            "/api/gpos",
            json={"name": "Domain test", "actor": "t", "reason": "test"},
        )
        gpo = resp.json()["gpo"]
        assert gpo["domain"] == "studio.local"
        resp = client.patch(
            f"/api/gpos/{gpo['guid']}",
            json={
                "name": "Domain test",
                "description": "",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
                "domain": "corp.example.test",
                "actor": "t",
                "reason": "set domain",
                "expected_revision": gpo["revision"],
            },
        )
        assert resp.status_code == 200
        updated = resp.json()["gpo"]
        assert updated["domain"] == "corp.example.test"


def test_gpmc_backup_excludes_external_filter_state(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Filter roundtrip"}).json()["gpo"]
        client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": gpo["revision"],
                "actor": "t",
                "reason": "add filter",
                "filter": {
                    "principal": "DOMAIN\\Admins",
                    "permission": "apply",
                    "inheritable": True,
                    "target_type": "group",
                },
            },
        )
        gpo = client.get(f"/api/gpos/{gpo['guid']}").json()["gpo"]
        client.put(
            f"/api/gpos/{gpo['guid']}/wmi-filter",
            json={
                "expected_revision": gpo["revision"],
                "actor": "t",
                "reason": "set wmi",
                "wmi_filter": {
                    "name": "WorkstationFilter",
                    "query": "select * from Win32_OperatingSystem",
                    "language": "WQL",
                },
            },
        )
        resp = client.get(f"/api/gpos/{gpo['guid']}/gpmc-backup")
        assert resp.status_code == 200
        backup_dir = tmp_path / "gpmc_backup"
        backup_dir.mkdir()
        with zipfile.ZipFile(io.BytesIO(resp.content)) as archive:
            archive.extractall(backup_dir)
        store.close()
        app.state.store = WorkspaceStore(tmp_path / "api2.db")
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "Round-trip with filters",
        })
        assert resp.status_code == 201
        imported = resp.json()["gpo"]
        assert imported["security_filters"] == []
        assert imported["wmi_filter"] is None


def test_gpp_group_crud_via_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP group policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "members": [
                        {
                            "sid": "S-1-5-21-1-2-3-500",
                            "name": "DOMAIN\\Domain Admins",
                            "action": "add",
                        }
                    ],
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"]) == 1
        assert gpo["gpp_collections"][0]["scope"] == "computer"
        assert len(gpo["gpp_collections"][0]["groups"]) == 1
        group_id = gpo["gpp_collections"][0]["groups"][0]["id"]
        assert group_id

        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "rename group",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "id": group_id,
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["gpp_collections"][0]["groups"][0]["name"] == "Admins"

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "remove group",
                "scope": "computer",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"]) == 0


def test_gpp_registry_crud_via_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP registry policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add registry",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                    "value": {
                        "name": "Enabled",
                        "value": "42",
                        "registry_type": "REG_DWORD",
                        "action": "create",
                    },
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"][0]["registry"]) == 1
        reg_id = gpo["gpp_collections"][0]["registry"][0]["id"]
        assert reg_id
        assert gpo["gpp_collections"][0]["registry"][0]["value"]["value"] == "42"

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/preferences/registry/{reg_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "remove registry",
                "scope": "computer",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"]) == 0


def test_gpp_member_crud_via_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP member policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        group_id = gpo["gpp_collections"][0]["groups"][0]["id"]

        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}/members",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add member",
                "scope": "computer",
                "member": {
                    "sid": "S-1-5-21-1-2-3-500",
                    "name": "DOMAIN\\Domain Admins",
                    "action": "add",
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"][0]["groups"][0]["members"]) == 1
        member_id = gpo["gpp_collections"][0]["groups"][0]["members"][0]["id"]
        assert member_id

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}/members/{member_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "remove member",
                "scope": "computer",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"][0]["groups"][0].get("members", [])) == 0


def test_gpp_dword_registry_value_round_trips(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP dword policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add dword",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                    "value": {
                        "name": "MaxValue",
                        "value": "4294967295",
                        "registry_type": "REG_DWORD",
                        "action": "create",
                    },
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        val = gpo["gpp_collections"][0]["registry"][0]["value"]
        assert val["registry_type"] == "REG_DWORD"
        assert val["value"] == "4294967295"


def test_gpp_invalid_group_name_returns_422(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP invalid policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "invalid group",
                "scope": "computer",
                "group": {
                    "name": "   ",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any(i["code"] == "empty_gpp_group_name" for i in issues)


def test_gpp_stale_revision_returns_409(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP conflict policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": 999,
                "actor": "tester",
                "reason": "stale",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 409


def test_gpp_group_with_ilt_filter(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP ILT policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group with filter",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "ilt_filter": {
                        "predicates": [
                            {
                                "type": "ou",
                                "value": "OU=Workstations,DC=example,DC=test",
                            }
                        ]
                    },
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        group = gpo["gpp_collections"][0]["groups"][0]
        assert group["ilt_filter"] is not None
        assert len(group["ilt_filter"]["items"]) == 1
        assert group["ilt_filter"]["items"][0]["type"] == "ou"


def test_gpp_group_rejects_reserved_unknown_attr(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Reserved attr policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group with reserved attr",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "unknown_attrs": [["name", "Overridden"]],
                },
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any("reserved" in i["message"].lower() for i in issues)


def test_gpp_registry_rejects_reserved_unknown_attr(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Reserved reg attr policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add registry with reserved attr",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Test",
                    "action": "update",
                    "value": {
                        "name": "Enabled",
                        "value": "1",
                        "registry_type": "REG_DWORD",
                        "action": "create",
                        "unknown_attrs": [["action", "D"]],
                    },
                },
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any("reserved" in i["message"].lower() for i in issues)


def test_gpp_group_rejects_reserved_unknown_child(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "Reserved child policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group with reserved child",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "unknown_children": ["<Properties action='D'/>"],
                },
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any("reserved" in i["message"].lower() for i in issues)


def test_gpp_group_ilt_filter_items_round_trip(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "ILT items round-trip"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group with items-format ILT",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "ilt_filter": {
                        "items": [
                            {
                                "type": "ou",
                                "value": "OU=Test,DC=example,DC=com",
                                "negate": False,
                                "bool_op": "AND",
                            },
                            "<FilterBattery not=\"0\" bool=\"AND\"/>",
                            {
                                "type": "group",
                                "value": "S-1-5-32-544",
                                "negate": True,
                                "bool_op": "OR",
                            },
                        ]
                    },
                },
            },
        )
        assert resp.status_code == 201
        result = resp.json()["gpo"]
        group = result["gpp_collections"][0]["groups"][0]
        assert group["ilt_filter"] is not None
        assert len(group["ilt_filter"]["items"]) == 3
        assert group["ilt_filter"]["items"][0]["type"] == "ou"
        assert group["ilt_filter"]["items"][1] == "<FilterBattery not=\"0\" bool=\"AND\"/>"
        assert group["ilt_filter"]["items"][2]["bool_op"] == "OR"


def test_gpp_os_ilt_criteria_round_trip_through_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "OS ILT round-trip"}).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "preserve imported OS criteria",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "ilt_filter": {
                        "items": [
                            {
                                "type": "os",
                                "os_criteria": {
                                    "os_class": "NT",
                                    "version": "WINTHRESHOLDSRV",
                                    "product_type": "SV",
                                    "edition": "NE",
                                    "service_pack": "NE",
                                },
                            }
                        ]
                    },
                },
            },
        )
        assert resp.status_code == 201
        payload = resp.json()
        predicate = payload["gpo"]["gpp_collections"][0]["groups"][0][
            "ilt_filter"
        ]["items"][0]
        assert predicate["os_criteria"] == {
            "os_class": "NT",
            "version": "WINTHRESHOLDSRV",
            "product_type": "SV",
            "edition": "NE",
            "service_pack": "NE",
        }
        assert any(
            issue["code"] == "ilt_os_server_10_family"
            for issue in payload["validation"]
        )
    store.close()


def test_gpp_ilt_reserved_attr_returns_422_not_500(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "ILT reserved attr policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group with reserved ILT attr",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "ilt_filter": {
                        "items": [
                            {
                                "type": "ou",
                                "value": "OU=Test",
                                "bool_op": "AND",
                                "unknown_attrs": [["bool", "OR"]],
                            }
                        ]
                    },
                },
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any("reserved" in i["message"].lower() for i in issues)
    store.close()
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP path id policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        gpo = resp.json()["gpo"]
        group_id = gpo["gpp_collections"][0]["groups"][0]["id"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "id": "divergent-body-id",
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        groups = gpo["gpp_collections"][0]["groups"]
        assert len(groups) == 1
        assert groups[0]["id"] == group_id
        assert groups[0]["name"] == "Admins"


def test_gpp_registry_edit_uses_path_id_not_body_id(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP path id reg policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add registry",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                },
            },
        )
        gpo = resp.json()["gpo"]
        reg_id = gpo["gpp_collections"][0]["registry"][0]["id"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/registry/{reg_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Updated",
                    "action": "update",
                    "id": "divergent-body-id",
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        registry = gpo["gpp_collections"][0]["registry"]
        assert len(registry) == 1
        assert registry[0]["id"] == reg_id
        assert registry[0]["key"] == r"Software\Policies\Updated"


def test_gpp_member_edit_uses_path_id_not_body_id(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP path id member policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Administrators",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        gpo = resp.json()["gpo"]
        group_id = gpo["gpp_collections"][0]["groups"][0]["id"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}/members",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add member",
                "scope": "computer",
                "member": {
                    "sid": "S-1-5-21-1-2-3-500",
                    "name": "DOMAIN\\Domain Admins",
                    "action": "add",
                },
            },
        )
        gpo = resp.json()["gpo"]
        member_id = gpo["gpp_collections"][0]["groups"][0]["members"][0]["id"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}/members/{member_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit member",
                "scope": "computer",
                "member": {
                    "sid": "S-1-5-21-1-2-3-500",
                    "name": "DOMAIN\\Admins",
                    "action": "add",
                    "id": "divergent-body-id",
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        members = gpo["gpp_collections"][0]["groups"][0]["members"]
        assert len(members) == 1
        assert members[0]["id"] == member_id
        assert members[0]["name"] == "DOMAIN\\Admins"


def test_post_gpp_group_with_existing_id_creates_new(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP create policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                    "id": "client-supplied-id",
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"][0]["groups"]) == 1
        original_id = gpo["gpp_collections"][0]["groups"][0]["id"]

        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add another group",
                "scope": "computer",
                "group": {
                    "name": "Operators",
                    "sid": "S-1-5-32-547",
                    "action": "update",
                    "id": original_id,
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        groups = gpo["gpp_collections"][0]["groups"]
        assert len(groups) == 2
        assert groups[0]["name"] == "Admins"
        assert groups[0]["id"] == original_id
        assert groups[1]["name"] == "Operators"
        assert groups[1]["id"] != original_id
        assert groups[1]["id"] != ""


def test_gpp_registry_value_crud_via_api(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP value policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add registry",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                    "value": {
                        "name": "Enabled",
                        "value": "42",
                        "registry_type": "REG_DWORD",
                        "action": "create",
                    },
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        reg_id = gpo["gpp_collections"][0]["registry"][0]["id"]
        value_id = gpo["gpp_collections"][0]["registry"][0]["value"]["id"]
        assert value_id

        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/registry/{reg_id}/values/{value_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "update value",
                "scope": "computer",
                "value": {
                    "name": "Enabled",
                    "value": "100",
                    "registry_type": "REG_DWORD",
                    "action": "update",
                    "id": value_id,
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        value = gpo["gpp_collections"][0]["registry"][0]["value"]
        assert value["value"] == "100"

        resp = client.request(
            "DELETE",
            f"/api/gpos/{gpo['guid']}/preferences/registry/{reg_id}/values/{value_id}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "remove value",
                "scope": "computer",
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"]) == 0


def test_put_gpp_group_nonexistent_id_returns_404(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP 404 policy"}
        ).json()["gpo"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/nonexistent",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit missing",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 404


def test_put_gpp_registry_nonexistent_id_returns_404(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP 404 reg policy"}
        ).json()["gpo"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/registry/nonexistent",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit missing",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 404


def test_put_gpp_member_nonexistent_id_returns_404(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP 404 member policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        gpo = resp.json()["gpo"]
        group_id = gpo["gpp_collections"][0]["groups"][0]["id"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{group_id}/members/nonexistent",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit missing member",
                "scope": "computer",
                "member": {
                    "sid": "S-1-5-21-1-2-3-500",
                    "name": "STUDIO\\Domain Admins",
                    "action": "add",
                },
            },
        )
        assert resp.status_code == 404


def test_put_gpp_registry_value_nonexistent_id_returns_404(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP 404 value policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add registry",
                "scope": "computer",
                "registry": {
                    "key": r"Software\Policies\Test",
                    "action": "update",
                },
            },
        )
        gpo = resp.json()["gpo"]
        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/registry/nonexistent/values/fake",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit missing value",
                "scope": "computer",
                "value": {
                    "name": "V1",
                    "value": "x",
                    "registry_type": "REG_SZ",
                    "action": "create",
                },
            },
        )
        assert resp.status_code == 404


def test_post_gpp_group_still_creates_after_must_exist_change(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post(
            "/api/gpos", json={"name": "GPP create policy"}
        ).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/groups",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "add group",
                "scope": "computer",
                "group": {
                    "name": "Admins",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 201
        gpo = resp.json()["gpo"]
        assert len(gpo["gpp_collections"][0]["groups"]) == 1

        resp = client.put(
            f"/api/gpos/{gpo['guid']}/preferences/groups/{gpo['gpp_collections'][0]['groups'][0]['id']}",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "edit existing",
                "scope": "computer",
                "group": {
                    "name": "Admins2",
                    "sid": "S-1-5-32-544",
                    "action": "update",
                },
            },
        )
        assert resp.status_code == 200
        gpo = resp.json()["gpo"]
        assert gpo["gpp_collections"][0]["groups"][0]["name"] == "Admins2"


# --- Regression tests for Plan 018 hardening ---


def test_backup_import_rejects_excessive_gpo_count(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("gpo_studio.backup._MAX_BACKUP_GPO_COUNT", 3)
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    gpos_xml = []
    for i in range(5):
        guid = f"00000000-0000-0000-0000-{i:012d}"
        gpo_dir = backup_dir / guid
        (gpo_dir / "Machine").mkdir(parents=True)
        gpos_xml.append(
            f"<GPO><Identifier>{guid}</Identifier>"
            f"<DisplayName>GPO {i}</DisplayName><Domain>test</Domain></GPO>"
        )
    manifest = (
        b'<?xml version="1.0" encoding="utf-8"?>'
        b'<BackupInstances xmlns="http://www.microsoft.com/GroupPolicy/Types">'
        + b"".join(f"<BackupInstance>{g}</BackupInstance>".encode() for g in gpos_xml)
        + b"</BackupInstances>"
    )
    (backup_dir / "manifest.xml").write_bytes(manifest)
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "test",
        })
        assert resp.status_code == 422
        assert resp.json()["error"]["message"] == "Invalid or unsafe backup content"


def test_backup_import_sanitizes_paths_in_errors(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    (backup_dir / "manifest.xml").write_bytes(b"not valid xml")
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "test",
        })
        assert resp.status_code == 422
        msg = resp.json()["error"]["message"]
        assert str(tmp_path) not in msg
        assert str(backup_dir) not in msg


def test_backup_import_malformed_preg_returns_422(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    machine_dir = gpo_dir / "Machine"
    machine_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    (machine_dir / "Registry.pol").write_bytes(b"PReg\x01\x00\x00\x00\x00\x00")
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "test",
        })
        assert resp.status_code == 422
        assert str(tmp_path) not in resp.json()["error"]["message"]


def test_backup_import_malformed_gpp_returns_422(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    gpo_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    gpp_dir = gpo_dir / "Machine" / "Preferences" / "Groups"
    gpp_dir.mkdir(parents=True)
    (gpp_dir / "Groups.xml").write_bytes(b"<Groups><unclosed")
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "test",
        })
        assert resp.status_code == 422
        assert str(tmp_path) not in resp.json()["error"]["message"]


def test_backup_import_rejects_invalid_gpp_group_name(
    tmp_path, monkeypatch
) -> None:
    """GPP collections must be validated before persistence (Plan 015)."""
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(tmp_path))
    backup_dir = tmp_path / "backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    gpp_dir = gpo_dir / "Machine" / "Preferences" / "Groups"
    gpp_dir.mkdir(parents=True)
    (backup_dir / "manifest.xml").write_bytes(_MANIFEST_XML)
    (gpp_dir / "Groups.xml").write_bytes(
        b'<?xml version="1.0" encoding="utf-8"?>'
        b'<Groups xmlns="http://www.microsoft.com/GroupPolicy/GroupObjects">'
        b'<Group name="">'
        b'<Properties action="U" />'
        b'</Group>'
        b'</Groups>'
    )
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/backups/import", json={
            "path": str(backup_dir),
            "actor": "tester",
            "reason": "test invalid GPP",
        })
        assert resp.status_code == 422
        issues = resp.json()["error"].get("issues", [])
        assert any(i["code"] == "empty_gpp_group_name" for i in issues)

        gpos = client.get("/api/gpos").json()["items"]
        assert len(gpos) == 0, "Invalid GPO must not be persisted"


def test_plan_019_review_endpoints_and_structured_conflict(tmp_path: Path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        created = client.post("/api/gpos", json={"name": "Review policy"})
        payload = created.json()
        guid = payload["gpo"]["guid"]
        assert payload["artifact_capabilities"]["policy_report"]["enabled"] is True

        updated = client.patch(
            f"/api/gpos/{guid}",
            json={
                "expected_revision": 1,
                "name": "Review policy",
                "description": "updated",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
            },
        )
        assert updated.status_code == 200

        comparison = client.get(
            f"/api/gpos/{guid}/revisions/diff",
            params={"from_revision": 1, "to_revision": 2},
        )
        assert comparison.status_code == 200
        assert any(item["field"] == "description" for item in comparison.json()["metadata"])

        identical = client.get(
            f"/api/gpos/{guid}/revisions/diff",
            params={"from_revision": 2, "to_revision": 2},
        )
        assert identical.status_code == 422
        assert identical.json()["error"]["issues"][0]["code"] == "identical_revisions"

        report = client.get(f"/api/gpos/{guid}/report.txt")
        assert report.status_code == 200
        assert report.headers["content-type"].startswith("text/plain")
        assert "Review model SHA-256:" in report.text

        stale = client.patch(
            f"/api/gpos/{guid}",
            json={
                "expected_revision": 1,
                "name": "Stale",
                "description": "unsaved",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
            },
        )
        assert stale.status_code == 409
        detail = stale.json()["error"]
        assert detail["code"] == "revision_conflict"
        assert detail["expected_revision"] == 1
        assert detail["current_revision"] == 2


def test_backup_import_accepts_path_relative_to_configured_inbox(
    tmp_path: Path, monkeypatch
) -> None:
    inbox_dir = tmp_path / "inbox"
    inbox_dir.mkdir()
    backup_dir = inbox_dir / "relative-backup"
    _create_minimal_backup(backup_dir)
    monkeypatch.setenv("GPO_STUDIO_INBOX_DIR", str(inbox_dir))
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        capabilities = client.get("/api/imports/capabilities").json()
        assert capabilities["gpmc_backup"]["inbox_configured"] is True
        imported = client.post(
            "/api/backups/import",
            json={"path": "relative-backup"},
        )
        assert imported.status_code == 201
        assert imported.json()["gpo"]["name"] == "Imported Policy"
        assert imported.json()["gpo"]["status"] == "archived"
        forked = client.post(
            f"/api/gpos/{imported.json()['gpo']['guid']}/fork",
            json={"name": "Editable imported policy"},
        )
        assert forked.status_code == 201
        assert forked.json()["gpo"]["status"] == "draft"


def test_template_list_empty(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    if hasattr(app.state, "template_sources"):
        del app.state.template_sources
    with TestClient(app) as client:
        resp = client.get("/api/templates")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] >= 0


def test_template_ingest_and_list(tmp_path, monkeypatch) -> None:
    admx_dir = tmp_path / "admx_ingest"
    admx_dir.mkdir()
    (admx_dir / "test.admx").write_bytes(_ADMX_MINIMAL)
    (admx_dir / "test.adml").write_bytes(_ADML_MINIMAL)
    _setup_admx_env(tmp_path, monkeypatch)
    if hasattr(app.state, "template_sources"):
        del app.state.template_sources
    if hasattr(app.state, "admx_catalogue"):
        del app.state.admx_catalogue
    with TestClient(app) as client:
        resp = client.post("/api/templates/ingest", json={
            "name": "test-source",
            "kind": "local",
            "path": str(admx_dir),
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "test-source"
        assert data["policy_count"] >= 1
        listing = client.get("/api/templates")
        assert listing.status_code == 200
        assert listing.json()["count"] >= 1
        names = [s["name"] for s in listing.json()["items"]]
        assert "test-source" in names


def test_template_ingest_bad_path(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        resp = client.post("/api/templates/ingest", json={
            "name": "bad",
            "kind": "local",
            "path": str(tmp_path / "nonexistent"),
        })
        assert resp.status_code == 422


def test_template_collisions_empty(tmp_path, monkeypatch) -> None:
    _setup_admx_env(tmp_path, monkeypatch)
    if hasattr(app.state, "template_sources"):
        del app.state.template_sources
    with TestClient(app) as client:
        resp = client.get("/api/templates/collisions")
        assert resp.status_code == 200
        assert resp.json()["has_issues"] is False


def test_update_setting_comment(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Comment test"}).json()["gpo"]
        gpo = client.post(
            f"/api/gpos/{gpo['guid']}/settings",
            json={
                "expected_revision": gpo["revision"],
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Comment",
                    "value_name": "Value",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                    "comment": "original",
                },
            },
        ).json()["gpo"]
        setting_id = gpo["settings"][0]["id"]
        resp = client.patch(
            f"/api/gpos/{gpo['guid']}/settings/{setting_id}/comment",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "update comment",
                "comment": "updated comment",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["gpo"]["revision"] == 3
        assert resp.json()["gpo"]["settings"][0]["comment"] == "updated comment"
        stale = client.patch(
            f"/api/gpos/{gpo['guid']}/settings/{setting_id}/comment",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "stale",
                "comment": "stale",
            },
        )
        assert stale.status_code == 409
        not_found = client.patch(
            f"/api/gpos/{gpo['guid']}/settings/missing/comment",
            json={
                "expected_revision": 3,
                "actor": "tester",
                "reason": "missing",
                "comment": "missing",
            },
        )
        assert not_found.status_code == 404
        invalid = client.patch(
            f"/api/gpos/{gpo['guid']}/settings/{setting_id}/comment",
            json={
                "expected_revision": 3,
                "actor": "tester",
                "reason": "long",
                "comment": "x" * 1001,
            },
        )
        assert invalid.status_code == 422


def test_copy_settings(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        source = client.post("/api/gpos", json={"name": "Source"}).json()["gpo"]
        source = client.post(
            f"/api/gpos/{source['guid']}/settings",
            json={
                "expected_revision": source["revision"],
                "reason": "add computer setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Copy",
                    "value_name": "Computer",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        ).json()["gpo"]
        source = client.post(
            f"/api/gpos/{source['guid']}/settings",
            json={
                "expected_revision": source["revision"],
                "reason": "add user setting",
                "setting": {
                    "side": "user",
                    "hive": "HKCU",
                    "key": r"Software\Policies\Copy",
                    "value_name": "User",
                    "registry_type": "REG_DWORD",
                    "value": "2",
                },
            },
        ).json()["gpo"]
        target = client.post("/api/gpos", json={"name": "Target"}).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{target['guid']}/copy-settings",
            json={
                "expected_revision": target["revision"],
                "actor": "tester",
                "reason": "copy all",
                "source_guid": source["guid"],
            },
        )
        assert resp.status_code == 200
        copied = resp.json()["gpo"]
        assert copied["revision"] == 2
        assert {s["value_name"] for s in copied["settings"]} == {"Computer", "User"}
        target2 = client.post("/api/gpos", json={"name": "Target 2"}).json()["gpo"]
        user_only = client.post(
            f"/api/gpos/{target2['guid']}/copy-settings",
            json={
                "expected_revision": target2["revision"],
                "actor": "tester",
                "reason": "copy user only",
                "source_guid": source["guid"],
                "side": "user",
            },
        )
        assert user_only.status_code == 200
        assert {s["value_name"] for s in user_only.json()["gpo"]["settings"]} == {"User"}
        stale = client.post(
            f"/api/gpos/{target2['guid']}/copy-settings",
            json={
                "expected_revision": 1,
                "actor": "tester",
                "reason": "stale",
                "source_guid": source["guid"],
            },
        )
        assert stale.status_code == 409
        missing_source = client.post(
            f"/api/gpos/{target2['guid']}/copy-settings",
            json={
                "expected_revision": user_only.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "missing",
                "source_guid": "does-not-exist",
            },
        )
        assert missing_source.status_code == 404
        invalid = client.post(
            f"/api/gpos/{target2['guid']}/copy-settings",
            json={
                "expected_revision": user_only.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "invalid side",
                "source_guid": source["guid"],
                "side": "machine",
            },
        )
        assert invalid.status_code == 422


def test_bulk_policy_state(tmp_path, monkeypatch) -> None:
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Bulk state"}).json()["gpo"]
        gpo = client.post(
            f"/api/admx/policies/{_STATEFUL_ID}/configure",
            json={
                "gpo_guid": gpo["guid"],
                "side": "computer",
                "values": {"SubOption": True},
                "state": "enabled",
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "enable",
            },
        ).json()["gpo"]
        assert len(gpo["settings"]) == 2
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "bulk disabled",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "computer",
                "target_state": "disabled",
            },
        )
        assert resp.status_code == 200
        disabled = resp.json()["gpo"]
        assert disabled["revision"] == 3
        # Since WI-020, Disabled also emits a delete per element value name
        # (gpedit parity), so assert by name rather than by exact list.
        by_name = {item["value_name"]: item for item in disabled["settings"]}
        assert by_name["FeatureState"]["value"] == "0"
        assert by_name["SubOption"]["action"] == "delete"
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": disabled["revision"],
                "actor": "tester",
                "reason": "bulk not configured",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "computer",
                "target_state": "not_configured",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["gpo"]["settings"] == []
        stale = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": 1,
                "actor": "tester",
                "reason": "stale",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "computer",
                "target_state": "disabled",
            },
        )
        assert stale.status_code == 409
        not_found = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": resp.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "missing policy",
                "policy_ids": ["Synthetic.Policies.Stateful:MissingPolicy"],
                "side": "computer",
                "target_state": "disabled",
            },
        )
        assert not_found.status_code == 404
        side_mismatch = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": resp.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "side mismatch",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "user",
                "target_state": "disabled",
            },
        )
        assert side_mismatch.status_code == 422
        invalid = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": resp.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "bad state",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "computer",
                "target_state": "enabled",
            },
        )
        assert invalid.status_code == 422
        empty = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": resp.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "empty",
                "policy_ids": [],
                "side": "computer",
                "target_state": "disabled",
            },
        )
        assert empty.status_code == 422
        per_policy = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": resp.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "per-policy side",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "policy_sides": {
                    "Synthetic.Policies.Stateful:StatefulPolicy": "computer"
                },
                "target_state": "disabled",
            },
        )
        assert per_policy.status_code == 200
        inferred = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": per_policy.json()["gpo"]["revision"],
                "actor": "tester",
                "reason": "inferred side",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "target_state": "disabled",
            },
        )
        assert inferred.status_code == 200


def test_bulk_policy_state_both_class_requires_side(tmp_path, monkeypatch) -> None:
    # A Both-class policy with neither policy_sides[id] nor body.side must be
    # rejected with 422 (side_required), never 500. The ADMX parser validates
    # class_ at parse time, so the assert_never branch in _policy_side stays
    # dead code; this test exercises the legitimate Both-without-side path.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Both class bulk"}).json()["gpo"]
        both_qid = "Synthetic.Policies.Stateful:BothClassPolicy"
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "both without side",
                "policy_ids": [both_qid],
                "target_state": "enabled",
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any(i["code"] == "side_required" for i in issues)
        # The GPO is untouched: no revision bump, no settings written.
        fresh = client.get(f"/api/gpos/{gpo['guid']}").json()["gpo"]
        assert fresh["revision"] == gpo["revision"]
        assert fresh["settings"] == []


def test_bulk_policy_state_legacy_side_only_client(tmp_path, monkeypatch) -> None:
    # Backward compatibility: an old client that sends only ``side`` (no
    # ``policy_sides`` dict) must keep working — every policy uses that side.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Legacy side"}).json()["gpo"]
        gpo = client.post(
            f"/api/admx/policies/{_STATEFUL_ID}/configure",
            json={
                "gpo_guid": gpo["guid"],
                "side": "computer",
                "values": {"SubOption": True},
                "state": "enabled",
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "enable",
            },
        ).json()["gpo"]
        # Legacy request shape: top-level ``side`` only, no ``policy_sides``.
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "legacy bulk disabled",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "side": "computer",
                "target_state": "disabled",
            },
        )
        assert resp.status_code == 200
        disabled = resp.json()["gpo"]
        # Since WI-020, Disabled also emits a delete per element value name
        # (gpedit parity), so assert by name rather than by exact list.
        by_name = {item["value_name"]: item for item in disabled["settings"]}
        assert by_name["FeatureState"]["value"] == "0"
        assert by_name["SubOption"]["action"] == "delete"


def test_bulk_policy_state_rejects_unknown_policy_sides_key(
    tmp_path, monkeypatch
) -> None:
    # policy_sides keys not in policy_ids must be rejected, not silently
    # ignored — a typo in the key would otherwise leave a Both-class policy
    # un-sided with no signal.
    _setup_stateful_admx_env(tmp_path, monkeypatch)
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Unknown side key"}).json()["gpo"]
        resp = client.post(
            f"/api/gpos/{gpo['guid']}/bulk-policy-state",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "typo in policy_sides",
                "policy_ids": ["Synthetic.Policies.Stateful:StatefulPolicy"],
                "policy_sides": {
                    "Synthetic.Policies.Stateful:StatefulPolicy": "computer",
                    "Synthetic.Policies.Stateful:TypoPolicy": "computer",
                },
                "target_state": "disabled",
            },
        )
        assert resp.status_code == 422
        issues = resp.json()["error"]["issues"]
        assert any(i["code"] == "unknown_policy_side_key" for i in issues)


def test_starter_gpo_crud(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post(
            "/api/starter-gpos",
            json={
                "name": "Starter",
                "description": "Template",
                "template_version": "v1",
                "actor": "tester",
                "reason": "create starter",
            },
        )
        assert resp.status_code == 201
        starter = resp.json()["gpo"]
        assert starter["is_starter"] is True
        assert starter["template_version"] == "v1"
        assert starter["status"] == "draft"

        resp = client.get("/api/starter-gpos")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 1
        assert data["items"][0]["guid"] == starter["guid"]

        regular = client.post("/api/gpos", json={"name": "Regular"}).json()["gpo"]
        resp = client.get("/api/starter-gpos")
        assert resp.status_code == 200
        assert resp.json()["count"] == 1

        resp = client.patch(
            f"/api/gpos/{starter['guid']}",
            json={
                "expected_revision": starter["revision"],
                "name": "Starter",
                "description": "Updated starter",
                "computer_enabled": True,
                "user_enabled": True,
                "status": "draft",
                "actor": "tester",
                "reason": "update metadata",
            },
        )
        assert resp.status_code == 200
        starter = resp.json()["gpo"]
        assert starter["description"] == "Updated starter"

        resp = client.post(
            f"/api/gpos/{starter['guid']}/settings",
            json={
                "expected_revision": starter["revision"],
                "actor": "tester",
                "reason": "add setting",
                "setting": {
                    "side": "computer",
                    "hive": "HKLM",
                    "key": r"Software\Policies\Starter",
                    "value_name": "Enabled",
                    "registry_type": "REG_DWORD",
                    "value": "1",
                },
            },
        )
        assert resp.status_code == 201
        starter = resp.json()["gpo"]
        assert len(starter["settings"]) == 1

        resp = client.post(
            f"/api/starter-gpos/{starter['guid']}/derive",
            json={
                "name": "Derived",
                "actor": "tester",
                "reason": "derive",
            },
        )
        assert resp.status_code == 201
        derived = resp.json()["gpo"]
        assert derived["is_starter"] is False
        assert derived["source_guid"] == starter["guid"]
        assert derived["name"] == "Derived"
        assert len(derived["settings"]) == 1

        resp = client.post(
            f"/api/starter-gpos/{starter['guid']}/derive",
            json={
                "name": "Derived stale",
                "actor": "tester",
                "reason": "stale",
                "expected_revision": 1,
            },
        )
        assert resp.status_code == 409

        resp = client.post(
            "/api/starter-gpos/nonexistent-guid/derive",
            json={
                "name": "Derived",
                "actor": "tester",
                "reason": "missing",
            },
        )
        assert resp.status_code == 404

        resp = client.request(
            "DELETE",
            f"/api/starter-gpos/{starter['guid']}",
            json={"actor": "tester", "reason": "delete", "expected_revision": starter["revision"]},
        )
        assert resp.status_code == 204
        assert client.get(f"/api/gpos/{starter['guid']}").status_code == 404

        resp = client.request(
            "DELETE",
            "/api/starter-gpos/nonexistent-guid",
            json={"actor": "tester", "reason": "delete", "expected_revision": 1},
        )
        assert resp.status_code == 404

        resp = client.request(
            "DELETE",
            f"/api/starter-gpos/{regular['guid']}",
            json={
                "actor": "tester",
                "reason": "delete regular",
                "expected_revision": regular["revision"],
            },
        )
        assert resp.status_code == 404


def test_create_starter_gpo_requires_name(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post(
            "/api/starter-gpos",
            json={"actor": "tester", "reason": "missing name"},
        )
        assert resp.status_code == 422


def test_create_starter_gpo_requires_actor_and_reason(tmp_path) -> None:
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        resp = client.post("/api/starter-gpos", json={"name": "Starter"})
        assert resp.status_code == 422


def test_wi044_a_deny_gpo_advertises_the_refusal_it_will_actually_perform(
    tmp_path,
) -> None:
    """The capability payload and the download must agree (WI-044).

    WI-041 ruled that a deny `Set-GPPermission` cannot express is refused rather
    than approximated, and the two download endpoints do refuse. What did not
    move with that ruling was the payload the UI builds its buttons from:
    `artifact_capabilities` is derived from `validate_gpo`, which has no deny
    rule, so both artifacts advertised `enabled: true` and then returned 422.

    A refusal discovered at download time reads as a broken product; the same
    refusal stated up front reads as a considered boundary. This pins the
    agreement in both directions, because either half alone would pass while the
    product still lied.
    """
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "Deny filter policy"}).json()["gpo"]

        # The control. Without it this test would pass against a payload that
        # reported every artifact as unavailable for every GPO.
        before = client.get(f"/api/gpos/{gpo['guid']}").json()["artifact_capabilities"]
        assert before["powershell_plan"]["enabled"] is True
        assert before["studio_export"]["enabled"] is True
        assert client.get(f"/api/gpos/{gpo['guid']}/plan.ps1").status_code == 200

        added = client.post(
            f"/api/gpos/{gpo['guid']}/security-filters",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "keep this GPO off the workstations",
                "filter": {
                    "principal": "LAB\\Workstations",
                    "permission": "read",
                    "deny": True,
                },
            },
        )
        assert added.status_code == 201

        after = client.get(f"/api/gpos/{gpo['guid']}").json()["artifact_capabilities"]
        for artifact in ("powershell_plan", "studio_export"):
            assert after[artifact]["enabled"] is False, artifact
            # A capability that is off for a knowable reason must say the
            # reason -- the shape `gpmc_export` already keeps.
            assert "DENY" in after[artifact]["reason"], artifact

        # And the refusal itself is unchanged: this item is about advertising
        # the boundary, not softening it.
        for path in ("plan.ps1", "export.zip"):
            refused = client.get(f"/api/gpos/{gpo['guid']}/{path}")
            assert refused.status_code == 422, path
            codes = [i["code"] for i in refused.json()["error"]["issues"]]
            assert codes == ["deny_filter_not_expressible"], path


def test_wi046_a_gpp_registry_gpo_advertises_the_gpmc_backup_refusal(tmp_path) -> None:
    """WI-044 fixed an instance; this is the class (WI-046).

    `gpmc_export` was the entry WI-044 cited as the correct template — it
    already carried a `reason` — and it was advertising `enabled: true` for a
    GPO whose backup then refused. `gpmc_backup_bundle` covers four GPP
    families (`Drives`, `Groups`, `ScheduledTasks`, `Services`); `Registry` is
    not among them, has been authorable since 1.0, and neither `validate_gpo`
    nor `preserved_files` notices.
    """
    store = WorkspaceStore(tmp_path / "api.db")
    app.state.store = store
    app.state.owns_store = False
    with TestClient(app) as client:
        gpo = client.post("/api/gpos", json={"name": "GPP registry policy"}).json()["gpo"]

        # The control: a GPO with no preferences really can be backed up, so a
        # blanket `enabled: false` would not satisfy this test.
        before = client.get(f"/api/gpos/{gpo['guid']}").json()["artifact_capabilities"]
        assert before["gpmc_export"]["enabled"] is True
        assert client.get(f"/api/gpos/{gpo['guid']}/gpmc-backup").status_code == 200

        added = client.post(
            f"/api/gpos/{gpo['guid']}/preferences/registry",
            json={
                "expected_revision": gpo["revision"],
                "actor": "tester",
                "reason": "author a registry preference",
                "scope": "computer",
                "registry": {
                    "key": "Software\\Demo",
                    "value": {"name": "V", "value": "x", "registry_type": "REG_SZ"},
                },
            },
        )
        assert added.status_code == 201

        after = client.get(f"/api/gpos/{gpo['guid']}").json()["artifact_capabilities"]
        assert after["gpmc_export"]["enabled"] is False
        assert "unsupported" in after["gpmc_export"]["reason"].lower() or (
            "has not been verified" in after["gpmc_export"]["reason"]
        )

        refused = client.get(f"/api/gpos/{gpo['guid']}/gpmc-backup")
        assert refused.status_code == 422
        codes = [i["code"] for i in refused.json()["error"]["issues"]]
        assert codes == ["unsupported_native_gpp_extension"]

        # The Studio bundle and the plan are unaffected: this refusal belongs
        # to the native backup path alone, and over-reporting it would be the
        # same defect pointed the other way.
        assert after["studio_export"]["enabled"] is True
        assert after["powershell_plan"]["enabled"] is True
