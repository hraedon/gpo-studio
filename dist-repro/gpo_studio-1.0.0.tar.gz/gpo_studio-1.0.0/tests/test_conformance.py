from __future__ import annotations

import io
import zipfile
from pathlib import Path

import pytest

from gpo_studio.backup import BackupError, read_backup
from gpo_studio.conformance import (
    corpus,
    corrupt_backup_truncated_xml,
    cpassword_gpp_xml,
    fixture_all_registry_types,
    fixture_comprehensive,
    fixture_delete_operations,
    fixture_empty_and_default_values,
    fixture_gpp_groups_all_actions,
    fixture_gpp_registry_all_actions,
    fixture_ilt_all_predicates,
    fixture_link_shapes,
    fixture_security_filter_types,
    fixture_unicode_names_and_data,
    fixture_wmi_filter,
    malformed_preg_bad_header,
    malformed_preg_invalid_type,
    malformed_preg_truncated,
    normalize_gpo_for_backup_roundtrip,
    normalize_gpo_for_comparison,
    unsupported_ilt_nested_collection_xml,
)
from gpo_studio.export import export_bundle, gpmc_backup_bundle
from gpo_studio.gpp import contains_cpassword
from gpo_studio.ilt import parse_ilt
from gpo_studio.import_export import (
    backup_security_filters_to_model,
    backup_wmi_filter_to_model,
    collect_cse_metadata,
    collect_gpp_collections,
    extract_settings,
    extract_side_settings,
)
from gpo_studio.model import GPO, ValidationError
from gpo_studio.registry_pol import RegistryPolError, parse, serialize


def _extract_backup_zip(zip_bytes: bytes, dest: Path) -> Path:
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        archive.extractall(dest)
    return dest


def _import_backup_to_gpo(backup_dir: Path) -> GPO:
    backup = read_backup(backup_dir)
    assert len(backup.gpos) == 1
    backup_gpo = backup.gpos[0]
    content_root = backup_gpo.content_root
    assert content_root is not None

    machine_settings = extract_side_settings(content_root, "computer")
    user_settings = extract_side_settings(content_root, "user")
    all_settings = tuple(machine_settings + user_settings)
    cse_metadata = collect_cse_metadata(backup_gpo)
    gpp_collections = collect_gpp_collections(content_root)
    security_filters = backup_security_filters_to_model(backup_gpo.security_filters)
    wmi_filter = backup_wmi_filter_to_model(backup_gpo.wmi_filter)

    return GPO(
        guid=backup_gpo.guid,
        name=backup_gpo.display_name or "Imported GPO",
        settings=all_settings,
        security_filters=security_filters,
        wmi_filter=wmi_filter,
        gpp_collections=gpp_collections,
        cse_metadata=cse_metadata,
        domain=backup_gpo.domain or "studio.local",
        computer_enabled=backup_gpo.computer_enabled,
        user_enabled=backup_gpo.user_enabled,
    )


def _native_backup_corpus() -> list[tuple[str, GPO]]:
    unsupported = {"gpp_registry_all_actions", "comprehensive"}
    return [(name, gpo) for name, gpo in corpus() if name not in unsupported]


def _byte_stable_native_backup_corpus() -> list[tuple[str, GPO]]:
    lossy_preg = {"delete_operations", "empty_and_default_values"}
    return [
        (name, gpo)
        for name, gpo in _native_backup_corpus()
        if name not in lossy_preg
    ]


@pytest.mark.parametrize("name,gpo", _native_backup_corpus())
def test_gpmc_backup_roundtrip_preserves_semantic_fields(
    tmp_path: Path, name: str, gpo: GPO
) -> None:
    backup_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(backup_zip, tmp_path / name)
    imported = _import_backup_to_gpo(backup_dir)

    original_norm = normalize_gpo_for_backup_roundtrip(gpo)
    imported_norm = normalize_gpo_for_backup_roundtrip(imported)

    assert original_norm == imported_norm, (
        f"Round-trip mismatch for fixture '{name}':\n"
        f"Original: {original_norm}\n"
        f"Imported: {imported_norm}"
    )


@pytest.mark.parametrize("name,gpo", _native_backup_corpus())
def test_gpmc_backup_export_is_deterministic(name: str, gpo: GPO) -> None:
    first = gpmc_backup_bundle(gpo)
    second = gpmc_backup_bundle(gpo)
    assert first == second, f"GPMC backup export is not deterministic for '{name}'"


@pytest.mark.parametrize("name,gpo", _byte_stable_native_backup_corpus())
def test_gpmc_backup_reexport_is_stable(
    tmp_path: Path, name: str, gpo: GPO
) -> None:
    first_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(first_zip, tmp_path / f"{name}_first")
    imported = _import_backup_to_gpo(backup_dir)
    second_zip = gpmc_backup_bundle(imported)
    assert first_zip == second_zip, (
        f"Re-export differs from first export for '{name}'"
    )


@pytest.mark.parametrize("name,gpo", corpus())
def test_studio_bundle_export_is_deterministic(name: str, gpo: GPO) -> None:
    first = export_bundle(gpo)
    second = export_bundle(gpo)
    assert first == second, f"Studio bundle export is not deterministic for '{name}'"


def test_all_registry_types_roundtrip_through_preg() -> None:
    gpo = fixture_all_registry_types()
    pol_bytes = serialize(
        [s for s in gpo.settings if s.side == "computer"]
    )
    records = parse(pol_bytes)
    assert len(records) == len(gpo.settings)
    original_sorted = sorted(
        gpo.settings, key=lambda s: (s.key.casefold(), s.value_name.casefold())
    )
    for original, roundtrip in zip(original_sorted, records, strict=True):
        assert original.registry_type == roundtrip.registry_type
        assert original.value == roundtrip.value
        assert original.action == roundtrip.action


def test_delete_operations_roundtrip_through_preg() -> None:
    gpo = fixture_delete_operations()
    pol_bytes = serialize(list(gpo.settings))
    records = parse(pol_bytes)
    assert len(records) == 2
    assert all(r.action == "delete" for r in records)


def test_unicode_names_preserved_through_preg() -> None:
    gpo = fixture_unicode_names_and_data()
    pol_bytes = serialize(list(gpo.settings))
    records = parse(pol_bytes)
    assert len(records) == 2
    assert records[0].value == "\u30c6\u30b9\u30c8\u5024 \u00e9\u00e8\u00fc"
    assert records[1].value == ["\u65e5\u672c\u8a9e", "\u4e2d\u6587", "\ud55c\uad6d\uc5b4"]


def test_empty_values_roundtrip_through_preg() -> None:
    gpo = fixture_empty_and_default_values()
    pol_bytes = serialize(list(gpo.settings))
    records = parse(pol_bytes)
    assert len(records) == 4
    assert records[0].value == ""
    assert records[2].value == ""


def test_security_filters_roundtrip_through_gpmc_backup(tmp_path: Path) -> None:
    gpo = fixture_security_filter_types()
    backup_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(backup_zip, tmp_path / "sec_filters")
    imported = _import_backup_to_gpo(backup_dir)
    assert imported.security_filters == ()


def test_wmi_filter_roundtrip_through_gpmc_backup(tmp_path: Path) -> None:
    gpo = fixture_wmi_filter()
    backup_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(backup_zip, tmp_path / "wmi")
    imported = _import_backup_to_gpo(backup_dir)
    assert imported.wmi_filter is None


def test_gpp_groups_roundtrip_through_gpmc_backup(tmp_path: Path) -> None:
    gpo = fixture_gpp_groups_all_actions()
    backup_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(backup_zip, tmp_path / "gpp_groups")
    imported = _import_backup_to_gpo(backup_dir)
    assert len(imported.gpp_collections) == 1
    orig_groups = gpo.gpp_collections[0].groups
    imp_groups = imported.gpp_collections[0].groups
    assert len(imp_groups) == len(orig_groups)
    for orig, imp in zip(orig_groups, imp_groups, strict=True):
        assert orig.name == imp.name
        assert orig.sid == imp.sid
        assert orig.action == imp.action
        assert orig.description == imp.description


def test_gpp_registry_roundtrip_through_gpmc_backup(tmp_path: Path) -> None:
    gpo = fixture_gpp_registry_all_actions()
    with pytest.raises(ValidationError) as exc_info:
        gpmc_backup_bundle(gpo)
    assert exc_info.value.issues[0].code == "unsupported_native_gpp_extension"


def test_ilt_predicates_roundtrip_through_gpmc_backup(tmp_path: Path) -> None:
    gpo = fixture_ilt_all_predicates()
    backup_zip = gpmc_backup_bundle(gpo)
    backup_dir = _extract_backup_zip(backup_zip, tmp_path / "ilt")
    imported = _import_backup_to_gpo(backup_dir)
    assert len(imported.gpp_collections) == 1
    orig_filter = gpo.gpp_collections[0].groups[0].ilt_filter
    imp_filter = imported.gpp_collections[0].groups[0].ilt_filter
    assert orig_filter is not None
    assert imp_filter is not None
    assert len(imp_filter.predicates) == len(orig_filter.predicates)
    for orig_p, imp_p in zip(orig_filter.predicates, imp_filter.predicates, strict=True):
        assert orig_p.type == imp_p.type
        assert orig_p.negate == imp_p.negate
        assert orig_p.value == imp_p.value


def test_comprehensive_fixture_roundtrip(tmp_path: Path) -> None:
    gpo = fixture_comprehensive()
    with pytest.raises(ValidationError) as exc_info:
        gpmc_backup_bundle(gpo)
    assert exc_info.value.issues[0].code == "unsupported_native_gpp_extension"


def test_case_insensitive_key_matching() -> None:
    from gpo_studio.model import RegistrySetting

    s1 = RegistrySetting(
        id="s1", side="computer", hive="HKLM",
        key=r"Software\Policies\Test", value_name="Value",
        registry_type="REG_DWORD", value=1,
    )
    s2 = RegistrySetting(
        id="s2", side="computer", hive="HKLM",
        key=r"software\policies\test", value_name="value",
        registry_type="REG_DWORD", value=1,
    )
    assert s1.identity() == s2.identity()


def test_malformed_preg_bad_header_raises() -> None:
    with pytest.raises(RegistryPolError):
        parse(malformed_preg_bad_header())


def test_malformed_preg_truncated_raises() -> None:
    with pytest.raises(RegistryPolError):
        parse(malformed_preg_truncated())


def test_malformed_preg_invalid_type_raises() -> None:
    with pytest.raises(RegistryPolError):
        parse(malformed_preg_invalid_type())


def test_cpassword_detected_in_gpp_xml() -> None:
    assert contains_cpassword(cpassword_gpp_xml())


def test_cpassword_rejected_in_gpp_parse(tmp_path: Path) -> None:
    from gpo_studio.backup import BackupError
    from gpo_studio.import_export import collect_gpp_collections

    xml_bytes = cpassword_gpp_xml()
    assert contains_cpassword(xml_bytes)
    backup_dir = tmp_path / "cpassword_backup"
    gpo_dir = backup_dir / "11111111-2222-3333-4444-555555555555"
    groups_dir = gpo_dir / "Machine" / "Preferences" / "Groups"
    groups_dir.mkdir(parents=True)
    (groups_dir / "Groups.xml").write_bytes(xml_bytes)
    with pytest.raises(BackupError, match="cpassword"):
        collect_gpp_collections(gpo_dir)


def test_unsupported_ilt_nested_collection_preserved_as_unknown() -> None:
    from xml.etree import ElementTree as ET

    xml_bytes = unsupported_ilt_nested_collection_xml()
    root = ET.fromstring(xml_bytes)
    ilt = parse_ilt(root)
    assert len(ilt.unknown_predicates) > 0
    assert all(isinstance(p, str) for p in ilt.unknown_predicates)


def test_corrupt_backup_truncated_xml_raises(tmp_path: Path) -> None:
    backup_dir = tmp_path / "corrupt_backup"
    backup_dir.mkdir()
    (backup_dir / "manifest.xml").write_bytes(corrupt_backup_truncated_xml())
    with pytest.raises(BackupError):
        read_backup(backup_dir)


def test_partial_backup_missing_manifest_raises(tmp_path: Path) -> None:
    backup_dir = tmp_path / "partial_backup"
    backup_dir.mkdir()
    with pytest.raises(BackupError):
        read_backup(backup_dir)


def test_corpus_covers_all_fixture_builders() -> None:
    names = [name for name, _ in corpus()]
    expected = {
        "all_registry_types",
        "delete_operations",
        "side_status",
        "link_shapes",
        "security_filter_types",
        "wmi_filter",
        "gpp_groups_all_actions",
        "gpp_registry_all_actions",
        "ilt_all_predicates",
        "unicode_names_and_data",
        "empty_and_default_values",
        "comprehensive",
    }
    assert set(names) == expected


def test_normalize_gpo_for_comparison_strips_non_semantic_fields() -> None:
    from dataclasses import replace

    gpo1 = fixture_all_registry_types()
    gpo2 = replace(
        gpo1,
        revision=99,
        description="different",
        status="ready",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-06-01T00:00:00Z",
    )
    assert normalize_gpo_for_comparison(gpo1) == normalize_gpo_for_comparison(gpo2)


def test_normalize_gpo_for_backup_roundtrip_keeps_side_status_not_links() -> None:
    gpo = fixture_link_shapes()
    norm = normalize_gpo_for_backup_roundtrip(gpo)
    assert "links" not in norm
    assert norm["computer_enabled"] is True
    assert norm["user_enabled"] is True


def test_extract_settings_strips_long_form_hive_prefixes(tmp_path: Path) -> None:
    """HKEY_LOCAL_MACHINE\\ and HKEY_CURRENT_USER\\ prefixes must be stripped."""
    from gpo_studio.registry_pol import PolRecord
    from gpo_studio.registry_pol import serialize as serialize_pol

    records = [
        PolRecord(
            key="HKEY_LOCAL_MACHINE\\Software\\Policies\\Synthetic",
            value_name="Val",
            registry_type="REG_DWORD",
            value=1,
        ),
    ]
    pol_path = tmp_path / "Registry.pol"
    pol_path.write_bytes(serialize_pol(records))
    settings = extract_settings(pol_path, "computer")
    assert settings[0].key == "Software\\Policies\\Synthetic"


def test_extract_settings_rejects_hive_side_mismatch(tmp_path: Path) -> None:
    from gpo_studio.registry_pol import PolRecord
    from gpo_studio.registry_pol import serialize as serialize_pol

    pol_path = tmp_path / "Registry.pol"
    pol_path.write_bytes(serialize_pol([
        PolRecord(
            key=r"HKCU\Software\Policies\Synthetic",
            value_name="Val",
            registry_type="REG_DWORD",
            value=1,
        )
    ]))
    with pytest.raises(ValidationError) as exc_info:
        extract_settings(pol_path, "computer")
    assert exc_info.value.issues[0].code == "registry_hive_side_mismatch"
