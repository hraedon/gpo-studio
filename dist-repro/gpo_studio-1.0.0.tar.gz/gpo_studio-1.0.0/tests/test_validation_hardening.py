from __future__ import annotations

from gpo_studio.gpp import GppCollection, GppGroup
from gpo_studio.model import GPO, GPOLink, RegistrySetting, SecurityFilter, WmiFilter
from gpo_studio.validation import validate_gpo, validate_setting

_GUID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"


def _gpo(**kw: object) -> GPO:
    return GPO(guid=_GUID, name="Test", **kw)  # type: ignore[arg-type]


def _setting(key: str = r"Software\Policies\Test", **kw: object) -> RegistrySetting:
    return RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=key,
        value_name="Value",
        registry_type="REG_SZ",
        value="data",
        **kw,  # type: ignore[arg-type]
    )


def test_security_filter_empty_principal_error() -> None:
    gpo = _gpo(security_filters=(SecurityFilter(id="sf-1", principal="   "),))
    issues = validate_gpo(gpo)
    assert any(
        i.code == "empty_principal"
        and i.severity == "error"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_security_filter_duplicate_principal_different_case_error() -> None:
    gpo = _gpo(
        security_filters=(
            SecurityFilter(id="sf-1", principal="DOMAIN\\Admins"),
            SecurityFilter(id="sf-2", principal="DOMAIN\\ADMINS"),
        ),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "duplicate_principal"
        and i.path == "security_filters/sf-2/principal"
        for i in issues
    )


def test_security_filter_valid_no_errors() -> None:
    gpo = _gpo(
        security_filters=(
            SecurityFilter(id="sf-1", principal="DOMAIN\\Admins"),
            SecurityFilter(id="sf-2", principal="DOMAIN\\HelpDesk", permission="read"),
        ),
    )
    assert validate_gpo(gpo) == []


def test_security_filter_control_character_in_principal_error() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="Domain\x00Admins"),),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "control_character_in_principal"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_security_filter_principal_too_long_error() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="A" * 256),),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "principal_too_long"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_wmi_filter_empty_query_warning() -> None:
    gpo = _gpo(wmi_filter=WmiFilter(id="wf-1", name="filter", query=""))
    issues = validate_gpo(gpo)
    assert any(
        i.code == "empty_wmi_query"
        and i.severity == "warning"
        and i.path == "wmi_filter/query"
        for i in issues
    )


def test_wmi_filter_query_missing_from_error() -> None:
    gpo = _gpo(wmi_filter=WmiFilter(id="wf-1", name="filter", query="SELECT *"))
    issues = validate_gpo(gpo)
    assert any(
        i.code == "invalid_wmi_query"
        and i.severity == "error"
        and i.path == "wmi_filter/query"
        for i in issues
    )


def test_wmi_filter_query_missing_select_error() -> None:
    gpo = _gpo(wmi_filter=WmiFilter(id="wf-1", name="filter", query="FROM Win32_OperatingSystem"))
    issues = validate_gpo(gpo)
    assert any(i.code == "invalid_wmi_query" and i.severity == "error" for i in issues)


def test_wmi_filter_valid_query_no_issues() -> None:
    gpo = _gpo(
        wmi_filter=WmiFilter(
            id="wf-1", name="filter", query="SELECT * FROM Win32_OperatingSystem"
        ),
    )
    assert validate_gpo(gpo) == []


def test_wmi_filter_empty_name_error() -> None:
    gpo = _gpo(
        wmi_filter=WmiFilter(
            id="wf-1", name="   ", query="SELECT * FROM Win32_OperatingSystem"
        ),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "empty_wmi_filter_name"
        and i.severity == "error"
        and i.path == "wmi_filter/name"
        for i in issues
    )


def test_registry_key_null_byte_error() -> None:
    issues = validate_setting(_setting(key="Software\x00Policies"))
    assert any(i.code == "control_character_in_key" for i in issues)


def test_registry_key_too_long_error() -> None:
    issues = validate_setting(_setting(key="A" * 256))
    assert any(i.code == "registry_key_too_long" for i in issues)


def test_registry_key_exactly_255_chars_passes() -> None:
    issues = validate_setting(_setting(key="A" * 255))
    assert not any(i.code == "registry_key_too_long" for i in issues)


def test_registry_key_consecutive_backslashes_error() -> None:
    issues = validate_setting(_setting(key=r"Software\\Policies"))
    assert any(i.code == "consecutive_backslashes_in_key" for i in issues)


def test_registry_valid_key_no_issues() -> None:
    assert validate_setting(_setting(key=r"Software\Policies\Test")) == []


def test_security_filter_duplicate_principal_whitespace_difference() -> None:
    gpo = _gpo(
        security_filters=(
            SecurityFilter(id="sf-1", principal="DOMAIN\\Admins"),
            SecurityFilter(id="sf-2", principal=" DOMAIN\\Admins "),
        ),
    )
    issues = validate_gpo(gpo)
    assert any(i.code == "duplicate_principal" for i in issues)


def test_wmi_query_substring_not_keyword() -> None:
    gpo = _gpo(
        wmi_filter=WmiFilter(id="wf-1", name="filter", query="selection fromage"),
    )
    issues = validate_gpo(gpo)
    assert any(i.code == "invalid_wmi_query" and i.severity == "error" for i in issues)


def test_registry_key_whitespace_only_error() -> None:
    issues = validate_setting(_setting(key="   "))
    assert any(i.code == "invalid_registry_key" for i in issues)


def test_principal_format_domain_user_passes() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="DOMAIN\\Admins"),),
    )
    assert not any(i.code == "invalid_principal_format" for i in validate_gpo(gpo))


def test_principal_format_upn_passes() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="admin@example.com"),),
    )
    assert not any(i.code == "invalid_principal_format" for i in validate_gpo(gpo))


def test_principal_format_sid_passes() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="S-1-5-32-544"),),
    )
    assert not any(i.code == "invalid_principal_format" for i in validate_gpo(gpo))


def test_principal_format_plain_name_rejected() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="just a name"),),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "invalid_principal_format"
        and i.severity == "error"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_principal_format_empty_user_part_rejected() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="DOMAIN\\"),),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "invalid_principal_format"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_principal_format_empty_domain_part_rejected() -> None:
    gpo = _gpo(
        security_filters=(SecurityFilter(id="sf-1", principal="\\user"),),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "invalid_principal_format"
        and i.path == "security_filters/sf-1/principal"
        for i in issues
    )


def test_domain_empty_error() -> None:
    gpo = _gpo(domain="   ")
    issues = validate_gpo(gpo)
    assert any(
        i.code == "empty_domain"
        and i.severity == "error"
        and i.path == "domain"
        for i in issues
    )


def test_domain_too_long_error() -> None:
    gpo = _gpo(domain="A" * 256)
    issues = validate_gpo(gpo)
    assert any(
        i.code == "domain_too_long"
        and i.severity == "error"
        and i.path == "domain"
        for i in issues
    )


def test_domain_control_character_error() -> None:
    gpo = _gpo(domain="studio\x00.local")
    issues = validate_gpo(gpo)
    assert any(
        i.code == "control_character_in_domain"
        and i.severity == "error"
        and i.path == "domain"
        for i in issues
    )


def test_domain_format_suspicious_warning() -> None:
    gpo = _gpo(domain="domain!")
    issues = validate_gpo(gpo)
    assert any(
        i.code == "domain_format_suspicious"
        and i.severity == "warning"
        and i.path == "domain"
        for i in issues
    )


def test_domain_valid_fqdn_no_issues() -> None:
    gpo = _gpo(domain="corp.example.com")
    assert not any(i.path == "domain" for i in validate_gpo(gpo))


def test_domain_default_studio_local_no_issues() -> None:
    gpo = _gpo()
    assert not any(i.path == "domain" for i in validate_gpo(gpo))


def test_dword_bool_value_type_mismatch_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Enabled",
        registry_type="REG_DWORD",
        value=True,
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "type_mismatch"
        and i.severity == "error"
        and i.path == "settings/s1/value"
        for i in issues
    )


def test_qword_bool_value_type_mismatch_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Enabled",
        registry_type="REG_QWORD",
        value=False,
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "type_mismatch" and i.severity == "error" for i in issues
    )


def test_reg_sz_int_value_type_mismatch_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Path",
        registry_type="REG_SZ",
        value=42,
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "type_mismatch"
        and i.severity == "error"
        and i.path == "settings/s1/value"
        for i in issues
    )


def test_reg_expand_sz_non_string_type_mismatch_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Path",
        registry_type="REG_EXPAND_SZ",
        value=["a", "b"],
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "type_mismatch"
        and i.severity == "error"
        and i.path == "settings/s1/value"
        for i in issues
    )


def test_reg_binary_non_string_type_mismatch_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Blob",
        registry_type="REG_BINARY",
        value=42,
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "type_mismatch"
        and i.severity == "error"
        and i.path == "settings/s1/value"
        for i in issues
    )


def test_reg_binary_invalid_hex_error() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Blob",
        registry_type="REG_BINARY",
        value="zz",
    )
    issues = validate_setting(setting)
    assert any(
        i.code == "invalid_binary_hex"
        and i.severity == "error"
        and i.path == "settings/s1/value"
        for i in issues
    )


def test_reg_binary_valid_hex_no_issues() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Blob",
        registry_type="REG_BINARY",
        value="DEADBEEF",
    )
    assert validate_setting(setting) == []


def test_reg_binary_valid_hex_with_spaces_no_issues() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Blob",
        registry_type="REG_BINARY",
        value="DE AD BE EF",
    )
    assert validate_setting(setting) == []


def test_reg_sz_valid_string_no_issues() -> None:
    setting = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Path",
        registry_type="REG_SZ",
        value=r"C:\Temp",
    )
    assert validate_setting(setting) == []


def test_disabled_computer_side_with_gpp_collection_warns() -> None:
    gpo = _gpo(
        computer_enabled=False,
        gpp_collections=(
            GppCollection(
                scope="computer",
                groups=(GppGroup(name="Admins", sid="S-1-5-32-544"),),
            ),
        ),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "disabled_side_populated"
        and i.severity == "warning"
        and i.path == "computer_enabled"
        for i in issues
    )


def test_enabled_computer_side_with_gpp_collection_no_warning() -> None:
    gpo = _gpo(
        computer_enabled=True,
        gpp_collections=(
            GppCollection(
                scope="computer",
                groups=(GppGroup(name="Admins", sid="S-1-5-32-544"),),
            ),
        ),
    )
    issues = validate_gpo(gpo)
    assert not any(
        i.code == "disabled_side_populated" and i.path == "computer_enabled"
        for i in issues
    )


def test_disabled_user_side_with_gpp_collection_warns() -> None:
    gpo = _gpo(
        user_enabled=False,
        gpp_collections=(
            GppCollection(
                scope="user",
                groups=(GppGroup(name="Admins", sid="S-1-5-32-544"),),
            ),
        ),
    )
    issues = validate_gpo(gpo)
    assert any(
        i.code == "disabled_side_populated"
        and i.severity == "warning"
        and i.path == "user_enabled"
        for i in issues
    )


def test_disabled_side_with_empty_gpp_collection_no_warning() -> None:
    gpo = _gpo(
        computer_enabled=False,
        gpp_collections=(
            GppCollection(scope="computer"),
        ),
    )
    issues = validate_gpo(gpo)
    assert not any(
        i.code == "disabled_side_populated" and i.path == "computer_enabled"
        for i in issues
    )


def test_multi_sz_item_count_exceeded_in_setting() -> None:
    from gpo_studio.registry_pol import _MAX_MULTI_SZ_ITEMS

    s = RegistrySetting(
        id="s1",
        side="computer",
        hive="HKLM",
        key=r"Software\Policies\Test",
        value_name="Value",
        registry_type="REG_MULTI_SZ",
        value=[f"item{i}" for i in range(_MAX_MULTI_SZ_ITEMS + 1)],
    )
    issues = validate_setting(s)
    assert any(i.code == "item_count_exceeded" for i in issues)


def test_link_target_cn_container_passes_validation() -> None:
    gpo = _gpo(
        links=(
            GPOLink(id="l1", target="CN=Domain Controllers,DC=ad,DC=hraedon,DC=com"),
        ),
    )
    issues = validate_gpo(gpo)
    assert not any(i.code == "invalid_link_target" for i in issues)


def test_multi_sz_item_count_exceeded_in_gpp_registry() -> None:
    from gpo_studio.gpp import GppRegistry, GppRegistryValue
    from gpo_studio.registry_pol import _MAX_MULTI_SZ_ITEMS

    reg = GppRegistry(
        key=r"Software\Test",
        hive="HKLM",
        action="update",
        value=GppRegistryValue(
            name="Multi",
            value=[f"item{i}" for i in range(_MAX_MULTI_SZ_ITEMS + 1)],
            registry_type="REG_MULTI_SZ",
        ),
    )
    col = GppCollection(scope="computer", registry=(reg,))
    gpo = _gpo(gpp_collections=(col,))
    issues = validate_gpo(gpo)
    assert any(i.code == "item_count_exceeded" for i in issues)
